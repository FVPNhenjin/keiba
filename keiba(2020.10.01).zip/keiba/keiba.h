#define Width 1450
#define Height 910
//�s�N�Z��10���Ƃɕ���
#define mwid 10
//�s�N�Z��13���Ƃɕ���
#define mhei 13
int flame = 0;
enum class FORM {
	win,//�P��
	top3,//����
	conbi,//�n�A
	seq_conbi,//�A�P
	wide,//���C�h
	triple,//�O�A��
	seq_triple,//�O�A�P
	nullp,//�Ō�̒萔�Bend�ɂĎg����B
};
FORM begin(FORM) {
	return FORM::win;
}
FORM end(FORM) {
	return FORM::nullp;
}
FORM operator++(FORM& form) {
	return form = FORM(underlying_type<FORM>::type(form) + 1);
}
bool operator>(FORM& form,FORM form1) {
	return underlying_type<FORM>::type(form) > underlying_type<FORM>::type(form1);
}
FORM operator*(FORM form) { return form; }
int operator*(const FORM& form, int i) {
	return underlying_type<FORM>::type(form) * i;
}
enum SUB {
	none,//���n�𒆐S�Ƃ����ʏ���
	flow,//�������
	box,//�{�b�N�X���
	formation, //�t�H�[���[�V�������
};
struct FBF {
	FBF(int nx, int ny, int nwid, int nhei, int nnum) :x(nx), y(ny), wid(nwid), hei(nhei), num(nnum){

	}
	FBF(int nx, int ny) :x(nx), y(ny), wid(0), hei(0), num(0) {

	}
	int x;//����{�^���̍���X���W
	int y;//����{�^���̍���Y���W
	int wid;//����{�^���̉���
	int hei;//����{�^���̍���
	int num;//�n�ԍ�
	bool operator==(const FBF &fbf) {
		return (x == fbf.x && y == fbf.y);
	}
	bool operator==(const int & fbfx) {
		return (x == fbfx);
	}
	bool operator<(const FBF& fbf) {
		return (x * 10 + num < fbf.x * 10 + fbf.num);
	}
};
bool FBFS(vector<FBF>::iterator fbf1, vector<FBF>::iterator fbf2) {
	return fbf1->num < fbf2->num;
}
enum MODE {
	bet,
	race,
	result,
	config,
	io,
};
enum SOUND {
	SEselect,//�x�b�g���j���[����A�n�I���A�n���A���[�X�J�n�A�I��
	SEbet,//�ʏ�y��FBF�ł̌ʃx�b�g
	SEallbet,//�ʏ�y��FBF�ł�ALL�x�b�g
	SEinfo,//�n���E�n�I��
	SEbetmenu,//BET�ꗗ�ł̑���S��
	SEFBF,//FBF�{�^���N���b�N�AFBF���쓙
	SEcancel,//���߂��AFBF����ʏ�֖߂鎞
	SEwin,//�z�������������ɗ���SE
};
enum BNAME {//�{�^���ꗗ�B
	menubar,
	horse,
	info,
	bet1,
	bet2,
	start,
	betrate,
	Undo,
	betlist,	
	Option,
	End,
	bflow,
	bbox,
	bforma,
	FBFplot,
	FBFbaken,
	up,
	down,
	FBFallbet,
	FBFoddsnum,
	FBFcancel,
	
	
 };
enum INFOMATION {
	rank,//�n�̐l�C�ƒP���I�b�Y
	condi,//�n�̏�ԂƃX�^�C��
	record,//�ߋ�����
	
};

enum RATE {//���[�X���x�� 0.WBC 1.G1 2.G2 3.G3
	WBC,
	G1,
	G2,
	G3,
};
enum WEATHER {//�V�� 0.sunny 1.clowdy 2.rainy
	sunny,
	clowdy,
	rainy,
};
enum CONDITION {//�n���� 0.clear 1.semiheavy 2.heavy
	clear,//��
	semiheavy,//�c�d
	heavy,//�d
};
enum COLOR {
	white,//�n�ԍ��F�͍�
	black,//�n�ԍ��F�͔�
	red,//�n�ԍ��F�͔�
	blue,//�n�ԍ��F�͔�
	yellow,//�n�ԍ��F�͍�
	green,//�n�ԍ��F�͔�
	orange,//�n�ԍ��F�͔�
	pink,//�n�ԍ��F�͔�
};
enum STYLE {//���n�X�^�C�� 0.runaway 1.normal 2.catchup 3.runafter
	runaway,//����
	normal,//�i�s
	catchup,//����
	runafter,//�ǂ�
};
enum MIND {//�n��� 0.best 1.good 2.ok 3.notok 4.bad
	best,//�ŗ�
	good,//��
	ok,//��
	notok,//����
	bad,//��
};
struct HORSE {
	string name;//�n��
	COLOR color;//�n�F
	int fontcolor;//�n�ԍ��̐F�B�n�F���ƂɈقȂ邱�Ƃ�����B
	int backcolor;//�n�F���
	STYLE style;//�����X�^�C��
	MIND mind;
	RATE recordrate[5];//[�ߋ����[�X�ł̃��[�g]
	int num;//�n�ԍ��B���result�֌W�Ŏg����B
	int record[5];//[�ߋ����[�X�ł̏���]
	double value;//�����[�X�ł̔n���l�B��{�̓����_���B
	double win;//�P���I�b�Y�BNewGame�ɂĐݒ肳���B
	int rank;//�n�l�C���Bvalue�̏��ԂŌ��܂�B
};
struct RACE {
	RATE rate;	
	bool firld;//true = �� false = �_�[�g
	WEATHER weather;
	CONDITION condition;
	string name;//���[�X��
	int lane;//���������B1000�`3600M
	int horsecount;//12�`16�������[�X�Ƃ���B
	double totalvalue;//�n���l�̍��v�B��������Ɋe�n���̃I�b�Y���v�Z�����B
};
struct ReCalc {//�I�b�Y�Čv�Z�ɕK�v�ȏ��
	double resultvalue;//�Y���n�ȊO�̓��I�n�̉��l���v
	double value;//���I�n�̉��l
	double value2;//���I�n2�̉��l
	double odds;//�I�b�Y
	int bet;//BET���z
	double bs;//���C�h�n���̃I�b�Y�����ɕK�v�ȍ��z
};
class botan {
public:
	//�l�p�`�̃{�^�����̓o�^
	botan(int x,int xx,int y,int yy,BNAME b) :x1(x), x2(xx), y1(y), y2(yy), name(b), x3(0), y3(0)
	{		
		
	}
	//�O�p�`�̃{�^�����̓o�^
	botan(int x, int xx, int y, int yy,int tx,int ty, BNAME n) :x1(x), x2(xx), y1(y), y2(yy), name(n), x3(tx), y3(ty)
	{
		
	}
	botan(int x, int y, int r) :x1(x), x2(r), y1(y),y2(0),x3(0),y3(0),name(BNAME(0)) {

	}
	//�{�^���̍��W��Ԃ�
	void GetbotanRange(int& x, int& y, int & x2, int & y2) {
		x = x1;
		y = y1;
		x2 = this->x2;
		y2 = this->y2;
	}
	void GetbotanRange(int& x, int& y, int& x2, int& y2, int& x3, int& y3) {
		x = x1;
		y = y1;
		x2 = this->x2;
		y2 = this->y2;
		x3 = this->x3;
		y3 = this->y3;
	}
	//�{�^���Ȃǂ̎l�Ӕ͈͓��ɃJ�[�\�������݂��邩�𔻒f����B�͈͓��̏ꍇ��true��Ԃ��B
	bool range(const int x, const int y) {
		if (x3 != 0 && y3 != 0) {
			return TriangleRange(x, y);
		}
		else {
			if (y2 != 0) {
				if (x >= x1 && x <= x2 && y >= y1 && y <= y2) {
					return true;
				}
			}
			else {
				return CircleRange(x, y);
			}
		}
		return false;
	}
	bool TriangleRange(const int x,const int y) {
		struct vec {
			double x;//�x�N�g����X����
			double y;//�x�N�g����Y����
			double abs;//��Βl
		};
		vec AB, BC, CA, AO, BO, CO;
		AB.x = ((double)(x2) - x1);
		AB.y = ((double)(y2)- y1);
		AB.abs = sqrt(pow(x2 - x1, 2.0) + pow(y2 - y1, 2.0));
		BC.x = ((double)(x3)- x2);
		BC.y = ((double)(y3)- y2);
		BC.abs = sqrt(pow(x3 - x2, 2.0) + pow(y3 - y2, 2.0));
		CA.x = ((double)(x1)- x3);
		CA.y = ((double)(y1)- y3);
		CA.abs = sqrt(pow(x1 - x3, 2.0) + pow(y1 - y3, 2.0));
		AO.x = ((double)(x)- x1);
		AO.y = ((double)(y)- y1);
		AO.abs = sqrt(pow(x - x1, 2.0) + pow(y - y1, 2.0));
		BO.x = ((double)(x)- x2);
		BO.y = ((double)(y)- y2);
		BO.abs = sqrt(pow(x - x2, 2.0) + pow(y - y2, 2.0));
		CO.x = ((double)(x)- x3);
		CO.y = ((double)(y)- y3);
		CO.abs = sqrt(pow(x - x3, 2.0) + pow(y - y3, 2.0));
		double outABO, outBCO, outCAO;
		outABO = (double)(AB.y * AO.x) - (double)(AB.x * AO.y);
		outBCO = (double)(BC.y * BO.x) - (double)(BC.x * BO.y);
		outCAO = (double)(CA.y * CO.x) - (double)(CA.x * CO.y);
		if (x1 > 500) {
			/*DrawFormatString(100, 200, GetColor(0, 0, 0), "outABO = %f", outABO);
			DrawFormatString(100, 220, GetColor(0, 0, 0), "outBCO = %f", outBCO);
			DrawFormatString(100, 240, GetColor(0, 0, 0), "outCAO = %f", outCAO);*/
		}
		if ((outABO > 0 && outBCO > 0 && outCAO > 0) ||
			(outABO < 0 && outBCO < 0 && outCAO < 0) ){
			return true;
		}
		else {
			return false;
		}

	}
	bool CircleRange(const int x, const int y) {
		return pow(x1 - x, 2.0) + pow(y1 - y, 2.0) < pow(x2, 2.0);
	}
	const BNAME name;
private:
	const int x1;//��ʁE�{�^������܂��͉~���S�̂�X���W
	const int y1;//��ʁE�{�^������܂��͉~���S�̂�Y���W
	const int x2;//��ʁE�{�^���E����X���W�܂��͉~���a
	const int y2;//��ʁE�{�^���E����Y���W
	const int x3;//�O�p�`�̏ꍇ�̒��_��X���W
	const int y3;//�O�p�`�̏ꍇ�̒��_��Y���W
};

class bakenlavel {
public:
	bakenlavel(int lav[3],FORM f):form(f) {
		lavel.clear();
		for (int l = 0; lav[l] > 0 && l < 3; l++) {
			lavel.push_back(lav[l]);
		}
		
		lavelimg = 0;
	}
	~bakenlavel() {
		DeleteGraph(lavelimg);
	}
	vector<int> GetLavel() {
		return lavel;
	}
	int GetImage() {
		return lavelimg;
	}
	//�C�e���[�^����
	bakenlavel& operator =(vector<bakenlavel>::iterator bak) {
		return *bak;
	}
	//�n�ԍ����x���ɂ�铯�ꔻ��
	bool operator ==(vector<int> & lav) {
		switch (form) {
		case FORM::win:
		case FORM::top3:
			return lavel[0] == lav[0];
			break;
		case FORM::conbi:
		case FORM::wide:
			return count(lavel.begin(), lavel.end(), lav[0]) && count(lavel.begin(), lavel.end(), lav[1]);
			break;
		case FORM::seq_conbi:
			return (lavel[0] == lav[0]) && (lavel[1] == lav[1]);
			break;
		case FORM::triple:
		{
			bool equa = true;
			for (int t = 0; t < 3; t++) {
				if (count(lavel.begin(), lavel.end(), lav[t]) == 0) {
					equa = false;
					break;
				}
			}
			return equa;
		}
			break;
		case FORM::seq_triple:
		{
			bool equa = true;
			for (int t = 0; t < 3; t++) {
				equa &= (lavel[t] == lav[t]);
			}
			return equa;
		}
			break;
		}
		return false;
	}
	const bakenlavel& operator=(const bakenlavel& bak) {
		return bak;
	}
	////1���̔n���O���t�B�b�N���쐬�B
	//void CreateBakenGraph(const vector<HORSE>& h, const int& bimg, const int& lavelfont) {
	//	int wid = 0, hei = 0;
	//	int nx = 0, ny = 0;
	//	int fontsize;
	//	lavelimg = -1;
	//	int formcolor = GetColor(0, 0, 0);
	//	int betcolor = GetColor(0, 255, 0);
	//	GetGraphSize(bimg, &wid, &hei);
	//	int newlavelimg = MakeScreen(wid, hei, true);
	//	SetDrawScreen(newlavelimg);		
	//	
	//	SetDrawScreen(DX_SCREEN_BACK);
	//	DeleteGraph(newlavelimg);
	//}
	bool operator <(vector<int> & bak) {
		return false;
	}
	const FORM form;
private:
	int lavelimg;//1���̔n���g�ݍ��킹�ԍ��݂̂�`�ʂ����摜�B�����baken��bakenimg�Ƒg�ݍ��킹�邱�ƂŔn���摜��\������B
	vector<int> lavel;
	
};

bool operator==(bakenlavel & bak, vector<int> lav) {
	vector<int>lavel(bak.GetLavel());
	switch (bak.form) {
	case FORM::win:
	case FORM::top3:
		return lavel[0] == lav[0];
		break;
	case FORM::conbi:
	case FORM::wide:
		return count(lavel.begin(), lavel.end(), lav[0]) && count(lavel.begin(), lavel.end(), lav[1]);
		break;
	case FORM::seq_conbi:
		return (lavel[0] == lav[0]) && (lavel[1] == lav[1]);
		break;
	case FORM::triple:
	{
		bool equa = true;
		for (int t = 0; t < 3; t++) {
			if (count(lavel.begin(), lavel.end(), lav[t]) == 0) {
				equa = false;
				break;
			}
		}
		return equa;
	}
	break;
	case FORM::seq_triple:
	{
		bool equa = true;
		for (int t = 0; t < 3; t++) {
			equa &= (lavel[t] == lav[t]);
		}
		return equa;
	}
	break;
	}
	return false;
}

class baken {//�n����BET��L�����Z�����s���B�����ł͔n���̃I�b�Y��BET�z��L���A�g�ݍ��킹�ԍ���摜��bakenlavel�C�e���[�^�悪�L����B
public:
	baken(vector<bakenlavel>::iterator data, FORM Form, double Odds, double Modds) :datap(data),form(Form), odds(Odds), modds(Modds) {
		bet = 0;
		x = 0;
		y = 0;
	}
	baken(vector<bakenlavel>::iterator data, FORM Form, double Odds) :datap(data), form(Form), odds(Odds),modds(0) {		
		bet = 0;
		x = 0;
		y = 0;
	}		
	//�w��̔n�ԍ����n���Ɋ܂܂�Ă��邩�𒲂ׂ܂��B�Y������ꍇ��true��Ԃ��B
	bool Contain(int num) {		
		vector<int>lavel(datap->GetLavel());
		switch (form) {
		case FORM::win:
		case FORM::top3:
			if (lavel[0] == num) {
				return true;
			}
			break;
		case FORM::conbi:
		case FORM::wide:
			if (lavel[0] == num || lavel[1] == num) {
				return true;
			}
			break;
		}
		return false;
	}
	//�n�P�E�O�A���E�O�A�P�̏ꍇ�͑�2���n(2�ʗ\�z)���܂߂�B�܂�FBF�ł͔n�A�E���C�h���Y��
	bool Contain(int num, int num2) {		
		vector<int>lavel(datap->GetLavel());
		if (num == num2) {
			return false;
		}
		switch (form) {
		case FORM::conbi:
		case FORM::wide:
			if (lavel[0] == num || lavel[0] == num2) {
				if (lavel[1] == num || lavel[1] == num2) {
					return true;
				}
			}
			break;
		case FORM::seq_conbi:
			if (num == 0) {
				if (lavel[1] == num2) {
					return true;
				}
			}
			else {
				if (num2 == 0) {
					if (lavel[0] == num) {
						return true;
					}
				}
				else {
					if (lavel[0] == num && lavel[1] == num2) {
						return true;
					}
				}
			}
			break;
		case FORM::seq_triple:
			if (lavel[0] == num && lavel[1] == num2) {
				return true;
			}
			break;
		case FORM::triple:
		{
			int concount = 0;
			for (int n = 0; n < 3; n++) {
				if (lavel[n] == num || lavel[n] == num2) concount++;
			}
			if (concount == 2) {
				return true;
			}
		}
		break;
		}
		return false;
	}
	//FBF�̎O�A���E�O�A�P���Y��
	bool Contain(int num, int num2, int num3) {
		
		vector<int>lavel(datap->GetLavel());
		if (num == num2 || num3 == num2 || num == num3) {
			return false;
		}
		switch (form) {
		case FORM::triple:
		{
			int count = 0;
			for (int n = 0; n < 3; n++) {
				if (lavel[n] == num)count++;
				if (lavel[n] == num2)count++;
				if (lavel[n] == num3)count++;
			}
			if (count == 3) {
				return true;
			}
		}
		break;
		case FORM::seq_triple:
			if (num == lavel[0] && num2 == lavel[1] && num3 == lavel[2]) {
				return true;
			}
			break;
		}
		return false;
	}
	//�n�����x���ɂ�铯�ꔻ��
	bool operator==(vector<vector<FBF>::iterator> lav){
		switch (lav.size()) {
		case 2:
			return this->Contain(lav[0]->num, lav[1]->num);
			break;
		case 3:
			return this->Contain(lav[0]->num, lav[1]->num,lav[2]->num);
			break;
		}
		return false;
	}
	//�n����ނɂ�铯�ꔻ��
	bool operator==(FORM f) {
		return this->form == f;
	}
	//�n�����ɂ�铯�ꔻ��
	bool operator==(baken * bak) {
		vector<int>lav;
		bak->GetData(lav);
		switch (lav.size()) {
		case 1:
		{
			vector<int>lavel(datap->GetLavel());
			return lavel[0] == lav[0];
		}
		case 2:
			return this->Contain(lav[0], lav[1]);
			break;
		case 3:
			return this->Contain(lav[0], lav[1], lav[2]);
			break;
		}
		return false;
	}
	//�n���̃I�b�Y���܂��͔n�ԍ����ɂ���r����
	bool operator<(baken& bak) {
		
		vector<int>lavel(datap->GetLavel());
		vector<int>lav;
		bak.GetData(lav);
		int l = 0, ll = 0;
		switch (lav.size()) {
		case 2:
			l = lavel[0] * 100 + lavel[1];
			ll = lav[0] * 100 + lav[1];
			break;
		case 3:
			l = lavel[0] * 10000 + lavel[1] * 100 + lavel[2];
			ll = lav[0] * 10000 + lavel[1] * 100 + lav[2];
			break;
		}
		return l < ll;
	}
	
	//baken����
	baken operator =(baken& bak) {
		return bak;
	}
	//�I�b�Y��Ԃ��B
	double GetOdds() {
		return odds;
	}
	void GetOdds(double& modds, double& odds) {
		odds = this->odds;
		modds = this->modds;
	}
	//�n�ԍ��g�ݍ��킹�ƃI�b�Y��`�ʂ����O���t�B�b�N���쐬����B
	void CreateBakenGraph(const vector<HORSE>& h, int bimg,const int& lavelfont, const int& oddsfont) {		
		int wid = 0, hei = 0;
		int nx = 0, ny = 0;
		int Ocolor;				
		int formcolor = GetColor(0, 0, 0);
		int betcolor = GetColor(0, 255, 0);
		GetGraphSize(bimg, &wid, &hei);
		int newbakenimg = MakeScreen(wid, hei, true);
		SetDrawScreen(newbakenimg);
		if (odds < 10.0) {
			Ocolor = GetColor(200, 50, 75);
		}
		else {
			if (odds > 99.9) {
				if (odds > 999.9) {
					Ocolor = GetColor(250, 100, 250);
				}
				else {
					Ocolor = GetColor(225, 225, 5);
				}
			}
			else {
				Ocolor = GetColor(250, 250, 250);
			}
		}
		switch (form) {
		case FORM::win:
		case FORM::top3:
			//�P���E�����n����S�ĕ\��
		{
			
			if (modds > 0) {
				string format;
				if (odds > 99.9) {
					format = "%.0f";
				}
				else {
					format = "%.1f";
				}
				format += string("�`");
				if (modds > 9.9) {
					format += "%.0f";
				}
				else {
					format += "%.1f";
				}
				DrawFormatStringToHandle(nx + 46, ny + 15, Ocolor, oddsfont, format.c_str(), odds, modds);
			}
			else {
				DrawFormatStringToHandle(nx + 46, ny + 15, Ocolor, oddsfont, (odds > 10000) ? "%.0f" : "%.1f", odds, GetColor(0, 0, 0));

			}
		}
		break;

		case FORM::conbi:
			//���n��Allbet�Ƃ��Abet1�ɕ\��
		{
			
			DrawFormatStringToHandle(nx + 80, ny + 15, Ocolor, oddsfont, (odds > 999.9) ? "%.0f" : "%.1f", odds, GetColor(0, 0, 0));			
		}
		break;
		case FORM::wide:
			//���n��Allbet�Ƃ��Abet1�ɕ\��
		{
			
			string lav;
			if (odds > 999.9) {
				lav = "%.0f";
			}
			else {
				lav = "%.1f";
			}
			lav += " �` ";
			if (modds > 99.9) {
				lav += "%.0f";
			}
			else {
				lav += "%.1f";
			}
			DrawFormatStringToHandle(nx + 80, ny + 15, Ocolor, oddsfont, lav.c_str(), odds, modds, GetColor(0, 0, 0));			
		}
		break;
		case FORM::seq_conbi:
			//���n��Allbet�Ƃ��Abet1�Ɏ��n��1���Ƃ����ꍇ�̔n���Abet2�Ɏ��n��2���Ƃ����ꍇ�̔n����\��
		{
			
			DrawFormatStringToHandle(nx + 80, ny + 15, Ocolor, oddsfont, (odds > 999.9) ? "%.0f" : "%.1f", odds, GetColor(0, 0, 0));			
		}
		break;
		case FORM::triple:
			//���n��Allbet�̑ΏۂƂ����Abet1�Ebet2�̗̈�̋��E�𒆐S�Ƃ��ĕ\��
		{
			
			DrawFormatStringToHandle(nx + 169, ny + 15, Ocolor, oddsfont, (odds > 999.9) ? "%.0f" : "%.1f", odds, GetColor(0, 0, 0));
			
		}
		break;
		case FORM::seq_triple:
			//���n��Allbet�̑ΏۂƂ����Abet1�Ebet2�̗̈�̋��E�𒆐S�Ƃ��ĕ\��
		{
			
			DrawFormatStringToHandle(nx + 169, ny + 15, Ocolor, oddsfont, (odds > 999.9) ? "%.0f" : "%.1f", odds, GetColor(0, 0, 0));
			
		}
		break;
		}
		vector<int>lavel = datap->GetLavel();
		int fontsize;
		switch (form) {
			case FORM::win:
			case FORM::top3:
				//�P���E�����n����S�ĕ\��
			{
				
				DrawBox(nx + 7, ny + 7, nx + 40, ny + 41, h[lavel[0] - 1].backcolor, true);
				string lav = to_string(lavel[0]);
				fontsize = GetDrawStringWidthToHandle(lav.c_str(), lav.size(), lavelfont);
				DrawStringToHandle(nx + 23 - fontsize / 2, ny + 14, to_string(lavel[0]).c_str(), h[lavel[0] - 1].fontcolor, lavelfont);
			}
			break;

			case FORM::conbi:
				//���n��Allbet�Ƃ��Abet1�ɕ\��
			{
				
				fontsize = GetFontSizeToHandle(lavelfont) / 2;
				DrawBox(nx + 5, ny + 11, nx + fontsize * ((lavel[0] > 9) ? 2 : 1) + 9, ny + 38, h[lavel[0] - 1].backcolor, true);
				for (unsigned int s = 0, xx = nx + 7; s < lavel.size(); s++) {
					DrawStringToHandle(xx, ny + 13, to_string(lavel[s]).c_str(), h[lavel[s] - 1].fontcolor, lavelfont);
					if (s != lavel.size() - 1) {
						if (lavel[s] > 9) {
							xx += fontsize * 2;
						}
						else {
							xx += fontsize;
						}
						xx += 2;
						DrawStringToHandle(xx, ny + 13, string("-").c_str(), formcolor, lavelfont);
						xx += fontsize + 2;
						DrawBox(xx - 2, ny + 11, xx + fontsize * ((lavel[1] > 9) ? 2 : 1) + 5, ny + 38, h[lavel[1] - 1].backcolor, true);
					}
				}
			}
			break;
			case FORM::wide:
				//���n��Allbet�Ƃ��Abet1�ɕ\��
			{
				
				fontsize = GetFontSizeToHandle(lavelfont) / 2;
				DrawBox(nx + 5, ny + 11, nx + fontsize * ((lavel[0] > 9) ? 2 : 1) + 9, ny + 38, h[lavel[0] - 1].backcolor, true);
				string lav;
				for (unsigned int s = 0, xx = nx + 7; s < lavel.size(); s++) {
					DrawStringToHandle(xx, ny + 13, to_string(lavel[s]).c_str(), h[lavel[s] - 1].fontcolor, lavelfont);
					if (s != lavel.size() - 1) {
						if (lavel[s] > 9) {
							xx += fontsize * 2;
						}
						else {
							xx += fontsize;
						}
						xx += 2;
						DrawStringToHandle(xx, ny + 13, string(" ").c_str(), formcolor, lavelfont);
						xx += fontsize + 2;
						DrawBox(xx - 2, ny + 11, xx + fontsize * ((lavel[1] > 9) ? 2 : 1) + 5, ny + 38, h[lavel[1] - 1].backcolor, true);
					}
				}
			}
			break;
			case FORM::seq_conbi:
				//���n��Allbet�Ƃ��Abet1�Ɏ��n��1���Ƃ����ꍇ�̔n���Abet2�Ɏ��n��2���Ƃ����ꍇ�̔n����\��
			{
				
				fontsize = GetFontSizeToHandle(lavelfont) / 2;
				DrawBox(nx + 5, ny + 11, nx + fontsize * ((lavel[0] > 9) ? 2 : 1) + 9, ny + 38, h[lavel[0] - 1].backcolor, true);
				for (unsigned int s = 0, xx = nx + 7; s < lavel.size(); s++) {
					DrawStringToHandle(xx, ny + 13, to_string(lavel[s]).c_str(), h[lavel[s] - 1].fontcolor, lavelfont);
					if (s != lavel.size() - 1) {
						if (lavel[s] > 9) {
							xx += fontsize * 2;
						}
						else {
							xx += fontsize;
						}
						xx += 2;
						DrawStringToHandle(xx, ny + 13, string(">").c_str(), formcolor, lavelfont);
						xx += fontsize + 2;
						DrawBox(xx - 2, ny + 11, xx + fontsize * ((lavel[1] > 9) ? 2 : 1) + 5, ny + 38, h[lavel[1] - 1].backcolor, true);
					}
				}
			}
			break;
			case FORM::triple:
				//���n��Allbet�̑ΏۂƂ����Abet1�Ebet2�̗̈�̋��E�𒆐S�Ƃ��ĕ\��
			{
				
				fontsize = GetFontSizeToHandle(lavelfont) / 2;
				DrawBox(nx + 5, ny + 11, nx + fontsize * ((lavel[0] > 9) ? 2 : 1) + 9, ny + 38, h[lavel[0] - 1].backcolor, true);
				for (unsigned int s = 0, xx = nx + 7; s < lavel.size(); s++) {
					DrawStringToHandle(xx, ny + 13, to_string(lavel[s]).c_str(), h[lavel[s] - 1].fontcolor, lavelfont);
					if (s != lavel.size() - 1) {
						if (lavel[s] > 9) {
							xx += fontsize * 2;
						}
						else {
							xx += fontsize;
						}
						xx += 2;
						DrawStringToHandle(xx, ny + 13, string(" - ").c_str(), formcolor, lavelfont);
						xx += fontsize * 3 + 2;
						DrawBox(xx - 2, ny + 11, xx + fontsize * ((lavel[s + 1] > 9) ? 2 : 1) + 5, ny + 38, h[lavel[s + 1] - 1].backcolor, true);
					}
				}
			}
			break;
			case FORM::seq_triple:
				//���n��Allbet�̑ΏۂƂ����Abet1�Ebet2�̗̈�̋��E�𒆐S�Ƃ��ĕ\��
			{
				
				fontsize = GetFontSizeToHandle(lavelfont) / 2;
				DrawBox(nx + 5, ny + 11, nx + fontsize * ((lavel[0] > 9) ? 2 : 1) + 9, ny + 38, h[lavel[0] - 1].backcolor, true);
				for (unsigned int s = 0, xx = nx + 7; s < lavel.size(); s++) {
					DrawStringToHandle(xx, ny + 13, to_string(lavel[s]).c_str(), h[lavel[s] - 1].fontcolor, lavelfont);
					if (s != lavel.size() - 1) {
						if (lavel[s] > 9) {
							xx += fontsize * 2;
						}
						else {
							xx += fontsize;
						}
						xx += 2;
						DrawStringToHandle(xx, ny + 13, string(" > ").c_str(), formcolor, lavelfont);
						xx += fontsize * 3 + 2;
						DrawBox(xx - 2, ny + 11, xx + fontsize * ((lavel[s + 1] > 9) ? 2 : 1) + 5, ny + 38, h[lavel[s + 1] - 1].backcolor, true);
					}
				}
			}
			break;
			}
		bakenimg = MakeGraph(wid, hei);
		GetDrawScreenGraph(0, 0, wid, hei, bakenimg);
		SetDrawScreen(DX_SCREEN_BACK);
		DeleteGraph(newbakenimg);
	}
	//�n���O���t�B�b�N���擾�B
	int *GetBakenGraph() {
		return &bakenimg;
	}
	//�n���O���t�B�b�N���폜�B������menu��oddsdata�ɂ���baken�݂̂�ΏۂƂ���B
	void DeleteBaken() {
		DeleteGraph(bakenimg);
	}
	//�n�����\�������ꏊ��o�^����B
	void SetDisplayed(int dx, int dy) {
		x = dx;
		y = dy;
	}
	//�n������Ԃ��B
	/*void GetData(vector<int> &lavel,double &odds,double &modds,int &bet,int &x,int &y) {
		lavel = this->lavel;
		odds = this->odds;
		modds = this->modds;
		bet = this->bet;
		x = this->x;
		y = this->y;
	}
	void GetData(vector<int>& lavel, double& odds, double& modds, int& bet) {
		lavel = this->lavel;
		odds = this->odds;
		modds = this->modds;
		bet = this->bet;
	}*/
	void GetData(vector<int>& lavel) {
		
		lavel = datap->GetLavel();
	}
	void GetData(int& x, int& y) {
		x = this->x;
		y = this->y;
	}
	void GetData(int& bet) {
		if (this->bet != 0) {
			bet = this->bet;
		}
		else {
			bet = 0;
		}
	}
	//baken��form��int�^�œo�^���ĕԂ��B
	void GetFormToInt(int & f) {
		f = (int)(form);
	}
	bool Range(int tx, int ty) {
		int wid = (form < FORM::wide) ? 196 : 300;
		if (x < tx && x + wid > tx && y < ty && y + 50 > ty) {
			return true;
		}
		return false;
	}
	//�x�b�g�����Z����B
	bool AddBET(int chip) {
		bool r = false;
		if (bet + chip <= 999) {			
			bet += chip;
			r = true;			
		}
		return r;
	};
	//�x�b�g���L�����Z������B1��߂��ꍇ�̓x�b�g�z���w�肷��B
	void CANCEL() {
		bet = 0;
		
	}
	void CANCEL(int wait) {
		if (bet - wait >= 0) {
			bet -= wait;				
		}
	}
	//�������ʂƔn�����e���r����B���I�����ꍇ��true��Ԃ��B
	bool result(int first, int second, int third) {
		
		vector<int>lavel(datap->GetLavel());
		bool re = false;
		if (bet == 0) {
			//return re;
		}
		switch (form) {
		case  FORM::win://�P��
			if (lavel[0] == first) {
				re = true;
			}
			break;
		case  FORM::top3://����
			if (lavel[0] == first || lavel[0] == second || lavel[0] == third) {
				re = true;
			}
			break;
		case  FORM::conbi://�n�A
			if ((lavel[0] == first && lavel[1] == second) || (lavel[1] == first && lavel[0] == second)) {
				re = true;
			}
			break;
		case  FORM::seq_conbi://�A�P
			if (lavel[0] == first && lavel[1] == second) {
				re = true;
			}
			break;
		case  FORM::wide://���C�h
			{
			int count = 0;
				for (auto l = lavel.begin(); l != lavel.end(); l++) {
					if (*l == first) {
						count++;
					}
					if (*l == second) {
						count++;
					}
					if (*l == third) {
						count++;
					}
				}
				if (count == 2) {
					re = true;
				}
			}
			break;
		case  FORM::triple://�O�A��
		{
			int count = 0;
			for (auto l = lavel.begin(); l != lavel.end(); l++) {
				if (*l == first) {
					count++;
				}
				if (*l == second) {
					count++;
				}
				if (*l == third) {
					count++;
				}
			}
			if (count == 3) {
				re = true;
			}
		}
			break;
		case  FORM::seq_triple://�O�A�P
			if (lavel[0] == first && lavel[1] == second && lavel[2] == third) {
				re = true;
			}
			break;
		}
		return re;
	}
	
private:
	
	const vector<bakenlavel>::iterator datap;//menu�ɂ���oddsdata�x�N�^�[�ւ̃C�e���[�^�BAddBET�Ȃǂł͂�������oddsdata�ɃA�N�Z�X����B
	const FORM form;//�n���`��	
	const double odds;//���̔n���̃I�b�Y
	const double modds;//�����E���C�h����̍ő�I�b�Y�B����ȊO�̏ꍇ��0�Ƃ���B
	int bet;//�x�b�g�z���v�B�����ł̃x�b�g�͖����Ƃ���B
	int x, y;//�n�����\���������W�Boddsdata�ł͂������ = 0�ƂȂ邪displayed�ł�SetDisplayed�ɂč��W���ݒ肳���B
	int bakenimg;//bakenlavel�ɂ���n���摜�ɃI�b�Y���������������́B
};

class menu {
public:	
	menu(FORM Form, int img, int allimg) :form(Form), bimg(img), all(allimg) {
				
	}
	//bakendata������������B
	void ClearBakenData() {
		bakendata.clear();
	}
	//bakendata�ɂĉ摜���쐬������
	void CreateBakenBack(const vector<HORSE>& ho, const int& bimg, const int& lavelfont) {
		int lavel[3] = { 0,0,0 };
		auto data = bakendata.begin();
		switch (form) {
		case FORM::win://top3���܂�
			for(unsigned int h = 1; h < ho.size() + 1; h++) {
				lavel[0] = h;
				bakendata.emplace_back(lavel, form);
				
			}
			for(unsigned int h = 1; h < ho.size() + 1; h++) {
				lavel[0] = h;
				bakendata.emplace_back(lavel, FORM::top3);
				
			}
			data = bakendata.begin();
			for(unsigned int h = 1; h < ho.size() * 2 + 1; h++) {
				bakenmap[h] = data;
				data++;
			}
			break;
		case FORM::conbi:
			for(unsigned int h = 1; h < ho.size(); h++) {
				for(unsigned int hh = h + 1; hh < ho.size() + 1; hh++) {
					lavel[0] = h;
					lavel[1] = hh;
					bakendata.emplace_back(lavel, form);
					
				}
			}
			data = bakendata.begin();
			for(unsigned int h = 1; h < ho.size(); h++) {
				for(unsigned int hh = h + 1; hh < ho.size() + 1; hh++) {
					bakenmap[h * 100 + hh] = data;
					data++;
				}
			}
			break;
		case FORM::seq_conbi:
			for(unsigned int h = 1; h < ho.size() + 1; h++) {
				for(unsigned int hh = 1; hh < ho.size() + 1; hh++) {
					if (h != hh) {
						lavel[0] = h;
						lavel[1] = hh;
						bakendata.emplace_back(lavel, form);
						
					}
				}
			}
			data = bakendata.begin();
			for(unsigned int h = 1; h < ho.size() + 1; h++) {
				for(unsigned int hh = 1; hh < ho.size() + 1; hh++) {
					if (h != hh) {
						bakenmap[h * 100 + hh] = data;
						data++;
					}
				}
			}
			break;
		case FORM::wide:
			for(unsigned int h = 1; h < ho.size(); h++) {
				for(unsigned int hh = h + 1; hh < ho.size() + 1; hh++) {
					lavel[0] = h;
					lavel[1] = hh;
					bakendata.emplace_back(lavel, form);
					
				}
			}
			data = bakendata.begin();
			for(unsigned int h = 1; h < ho.size(); h++) {
				for(unsigned int hh = h + 1; hh < ho.size() + 1; hh++) {
					bakenmap[h * 100 + hh] = data;
					data++;
				}
			}
			break;
		case FORM::triple:
			for(unsigned int h = 1; h < ho.size() - 1; h++) {
				for(unsigned int hh = h + 1; hh < ho.size(); hh++) {
					for(unsigned int hhh = hh + 1; hhh < ho.size() + 1; hhh++) {
						lavel[0] = h;
						lavel[1] = hh;
						lavel[2] = hhh;
						bakendata.emplace_back(lavel, form);
						
					}
				}
			}
			data = bakendata.begin();
			for(unsigned int h = 1; h < ho.size() - 1; h++) {
				for(unsigned int hh = h + 1; hh < ho.size(); hh++) {
					for(unsigned int hhh = hh + 1; hhh < ho.size() + 1; hhh++) {
						bakenmap[h * 10000 + hh * 100 + hhh] = data;
						data++;
					}
				}
			}
			break;
		case FORM::seq_triple:
			for(unsigned int h = 1; h < ho.size() + 1; h++) {
				for(unsigned int hh = 1; hh < ho.size() + 1; hh++) {
					for(unsigned int hhh = 1; hhh < ho.size() + 1; hhh++) {
						if (h != hh && h != hhh && hh != hhh) {
							lavel[0] = h;
							lavel[1] = hh;
							lavel[2] = hhh;
							bakendata.emplace_back(lavel, form);
							
						}
					}
				}
			}
			data = bakendata.begin();
			for(unsigned int h = 1; h < ho.size() + 1; h++) {
				for(unsigned int hh = 1; hh < ho.size() + 1; hh++) {
					for(unsigned int hhh = 1; hhh < ho.size() + 1; hhh++) {
						if (h != hh && h != hhh && hh != hhh) {
							bakenmap[h * 10000 + hh * 100 + hhh] = data;
							data++;
						}
					}
				}
			}
			break;
		}		
	}
	//BET�Ώۂ̔n����\���Bvector<HORSE>��fontcolor,backcolor�����ɔn�����̃��x����F�t������B
	void DisplayBaken(const  vector<HORSE> & h,const int & subselect,int chip, const int& lavelfont,const int& bakenback) {
		/*int y = 3 + ((submenu > none && form != FORM::win) ? mhei * 4 : 0);
		int x = 654;*/
		int x = 0, y = 0;
		int count = 1;
		//�n���̕\��
		auto dis = displayed.begin();
		auto eight = subpart;
		int fontsize = GetFontSizeToHandle(lavelfont);
		int betcolor = GetColor(0, 255, 0);
		int totalbet = 0;
		if (submenu > SUB::none) {
			if (subpart != displayed.end()) {
				dis = subpart;
				while (eight != displayed.end() && count < 9) {
					eight++;
					count++;
				}
				int x, y,dx;
				GetGraphSize(bakenback, &x, &y);
				if (form < FORM::wide) {
					x /= 2;
					dx = 1003;
				}
				else {
					dx = 953;					
				}
				y = ((displayed.size() > 7) ? 8 : displayed.size()) * mhei * 4;
				DrawRectGraph(dx, 4 + mhei * 4, 1, 1,x, y, bakenback, true);
			}
			else {
				dis = displayed.end();
			}
		}
		else {
			if (displayed.size() > 0) {
				int x, y;
				GetGraphSize(bakenback, &x, &y);
				y = hcount * mhei * 4;
				DrawRectGraph(653, 1, 1, 1, (form == FORM::conbi) ? x / 2 : x, y, bakenback, true);
			}
		}
		count = 1;
		for (; dis != displayed.end(); dis++, y += mhei * 4,count++) {	
			if (submenu > SUB::none){
				if(displayed.size() > 8 ){
					if (dis == eight) {
						break;
					}
				}
			}
			switch (submenu) {
			case SUB::none:
				dis->GetData(x, y);
				break;
			case SUB::flow:
			case SUB::box:
			case SUB::formation:	
				//�摜�̍��W���͎��Ȃ�
				y = mhei * 4 * count + 3;
				if (form < FORM::wide) {
					x = 1004;
				}
				else {
					x = 954;
				}
				break;
			}	
			int f = DrawGraph(x, y, *dis->GetBakenGraph(), true);
			if (f == -1) {
				f = 1;
			}
			x += (form >= FORM::wide) ? 262 : 157;
			dis->GetData(totalbet);
			DrawStringToHandle(x + ((totalbet >= 10) ? 0 : fontsize / 2), y + mhei, to_string(totalbet).c_str(), betcolor, lavelfont);
			/*if (odds < 10.0) {
				Ocolor = GetColor(200, 50, 75);
			}
			else {
				if (odds > 99.9) {
					if (odds > 999.9) {
						Ocolor = GetColor(250, 100, 250);
					}
					else {
						Ocolor = GetColor(225, 225, 5);
					}
				}
				else {
					Ocolor = GetColor(250, 250, 250);
				}
			}
			switch (form) {
			case FORM::win:
				//�P���E�����n����S�ĕ\��
			{
				DrawGraph(x, y + 1, bimg, true);
				hc = (count > hcount) ? count - hcount : count;
				DrawBox(x + 7, y + 6, x + 40, y + 41, h[hc - 1].backcolor, true);
				string lav = to_string(hc);
				fontsize = GetDrawStringWidthToHandle(lav.c_str(), lav.size(), lavelfont);
				DrawStringToHandle(x + 23 - fontsize / 2, y + 13, to_string(hc).c_str(), h[hc - 1].fontcolor, lavelfont);
				if (modds > 0) {
					string format;
					if (odds > 99.9) {
						format = "%.0f";
					}
					else {
						format = "%.1f";
					}
					format += string("�`");
					if (modds > 9.9) {
						format += "%.0f";
					}
					else {
						format += "%.1f";
					}
					DrawFormatStringToHandle(x + 46, y + 15, Ocolor, oddsfont, format.c_str(), odds, modds);
				}
				else {
					DrawFormatStringToHandle(x + 46, y + 15, Ocolor, oddsfont, (odds > 10000) ? "%.0f" : "%.1f", odds, GetColor(0, 0, 0));

				}
				fontsize = GetFontSizeToHandle(lavelfont) / 2;
				DrawStringToHandle(x + 157 + ((totalbet > 10) ? 0 : fontsize), y + 13, to_string(totalbet).c_str(), betcolor, lavelfont);
				if (count == displayed.size() / 2) {
					y = 3 - mhei * 4;
					x = 854;
				}
			}
			break;
			case FORM::conbi:
				//���n��Allbet�Ƃ��Abet1�ɕ\��
			{
				DrawGraph(x, y, bimg, true);
				fontsize = GetFontSizeToHandle(lavelfont) / 2;
				DrawBox(x + 5, y + 11, x + fontsize * ((lavel[0] > 9) ? 2 : 1) + 9, y + 38, h[lavel[0] - 1].backcolor, true);
				DrawFormatStringToHandle(x + 80, y + 15, Ocolor, oddsfont, (odds > 999.9) ? "%.0f" : "%.1f", odds, GetColor(0, 0, 0));
				DrawStringToHandle(x + 157 + ((totalbet > 10) ? 0 : fontsize), y + 13, to_string(totalbet).c_str(), betcolor, lavelfont);
				for (unsigned int s = 0, xx = x + 7; s < lavel.size(); s++) {
					DrawStringToHandle(xx, y + 13, to_string(lavel[s]).c_str(), h[lavel[s] - 1].fontcolor, lavelfont);
					if (s != lavel.size() - 1) {
						if (lavel[s] > 9) {
							xx += fontsize * 2;
						}
						else {
							xx += fontsize;
						}
						xx += 2;
						DrawStringToHandle(xx, y + 13, string("-").c_str(), formcolor, lavelfont);
						xx += fontsize + 2;
						DrawBox(xx - 2, y + 11, xx + fontsize * ((lavel[1] > 9) ? 2 : 1) + 5, y + 38, h[lavel[1] - 1].backcolor, true);
					}
				}
			}
			break;
			case FORM::wide:
				//���n��Allbet�Ƃ��Abet1�ɕ\��			
			{
				DrawGraph(x, y, bimg, true);
				fontsize = GetFontSizeToHandle(lavelfont) / 2;
				DrawBox(x + 5, y + 11, x + fontsize * ((lavel[0] > 9) ? 2 : 1) + 9, y + 38, h[lavel[0] - 1].backcolor, true);
				string lav;
				if (odds > 999.9) {
					lav = "%.0f";
				}
				else {
					lav = "%.1f";
				}
				lav += " �` ";
				if (modds > 99.9) {
					lav += "%.0f";
				}
				else {
					lav += "%.1f";
				}
				DrawFormatStringToHandle(x + 80, y + 15, Ocolor, oddsfont, lav.c_str(), odds, modds, GetColor(0, 0, 0));
				DrawStringToHandle(x + 262 + ((totalbet > 10) ? 0 : fontsize), y + 13, to_string(totalbet).c_str(), betcolor, lavelfont);
				for (unsigned int s = 0, xx = x + 7; s < lavel.size(); s++) {
					DrawStringToHandle(xx, y + 13, to_string(lavel[s]).c_str(), h[lavel[s] - 1].fontcolor, lavelfont);
					if (s != lavel.size() - 1) {
						if (lavel[s] > 9) {
							xx += fontsize * 2;
						}
						else {
							xx += fontsize;
						}
						xx += 2;
						DrawStringToHandle(xx, y + 13, string(" ").c_str(), formcolor, lavelfont);
						xx += fontsize + 2;
						DrawBox(xx - 2, y + 11, xx + fontsize * ((lavel[1] > 9) ? 2 : 1) + 5, y + 38, h[lavel[1] - 1].backcolor, true);
					}
				}
			}
			break;
			case FORM::seq_conbi:
				//���n��Allbet�Ƃ��Abet1�Ɏ��n��1���Ƃ����ꍇ�̔n���Abet2�Ɏ��n��2���Ƃ����ꍇ�̔n����\��
			{
				DrawGraph(x, y, bimg, true);
				fontsize = GetFontSizeToHandle(lavelfont) / 2;
				DrawBox(x + 5, y + 11, x + fontsize * ((lavel[0] > 9) ? 2 : 1) + 9, y + 38, h[lavel[0] - 1].backcolor, true);
				DrawFormatStringToHandle(x + 80, y + 15, Ocolor, oddsfont, (odds > 999.9) ? "%.0f" : "%.1f", odds, GetColor(0, 0, 0));
				DrawStringToHandle(x + 157 + ((totalbet > 10) ? 0 : fontsize), y + 13, to_string(totalbet).c_str(), betcolor, lavelfont);
				for (unsigned int s = 0, xx = x + 7; s < lavel.size(); s++) {
					DrawStringToHandle(xx, y + 13, to_string(lavel[s]).c_str(), h[lavel[s] - 1].fontcolor, lavelfont);
					if (s != lavel.size() - 1) {
						if (lavel[s] > 9) {
							xx += fontsize * 2;
						}
						else {
							xx += fontsize;
						}
						xx += 2;
						DrawStringToHandle(xx, y + 13, string(">").c_str(), formcolor, lavelfont);
						xx += fontsize + 2;
						DrawBox(xx - 2, y + 11, xx + fontsize * ((lavel[1] > 9) ? 2 : 1) + 5, y + 38, h[lavel[1] - 1].backcolor, true);
					}
				}
			}
			break;
			case FORM::triple:
				//���n��Allbet�̑ΏۂƂ����Abet1�Ebet2�̗̈�̋��E�𒆐S�Ƃ��ĕ\��
			{
				DrawGraph(x, y, bimg, true);
				fontsize = GetFontSizeToHandle(lavelfont) / 2;
				DrawBox(x + 5, y + 11, x + fontsize * ((lavel[0] > 9) ? 2 : 1) + 9, y + 38, h[lavel[0] - 1].backcolor, true);
				DrawFormatStringToHandle(x + 169, y + 15, Ocolor, oddsfont, (odds > 999.9) ? "%.0f" : "%.1f", odds, GetColor(0, 0, 0));
				DrawStringToHandle(x + 262 + ((totalbet > 10) ? 0 : fontsize), y + 13, to_string(totalbet).c_str(), betcolor, lavelfont);
				for (unsigned int s = 0, xx = x + 7; s < lavel.size(); s++) {
					DrawStringToHandle(xx, y + 13, to_string(lavel[s]).c_str(), h[lavel[s] - 1].fontcolor, lavelfont);
					if (s != lavel.size() - 1) {
						if (lavel[s] > 9) {
							xx += fontsize * 2;
						}
						else {
							xx += fontsize;
						}
						xx += 2;
						DrawStringToHandle(xx, y + 13, string(" - ").c_str(), formcolor, lavelfont);
						xx += fontsize * 3 + 2;
						DrawBox(xx - 2, y + 11, xx + fontsize * ((lavel[s + 1] > 9) ? 2 : 1) + 5, y + 38, h[lavel[s + 1] - 1].backcolor, true);
					}
				}
			}
			break;
			case FORM::seq_triple:
				//���n��Allbet�̑ΏۂƂ����Abet1�Ebet2�̗̈�̋��E�𒆐S�Ƃ��ĕ\��
			{
				DrawGraph(x, y, bimg, true);
				fontsize = GetFontSizeToHandle(lavelfont) / 2;
				DrawBox(x + 5, y + 11, x + fontsize * ((lavel[0] > 9) ? 2 : 1) + 9, y + 38, h[lavel[0] - 1].backcolor, true);
				DrawFormatStringToHandle(x + 169, y + 15, Ocolor, oddsfont, (odds > 999.9) ? "%.0f" : "%.1f", odds, GetColor(0, 0, 0));
				DrawStringToHandle(x + 262 + ((totalbet > 10) ? 0 : fontsize), y + 13, to_string(totalbet).c_str(), betcolor, lavelfont);
				for (unsigned int s = 0, xx = x + 7; s < lavel.size(); s++) {
					DrawStringToHandle(xx, y + 13, to_string(lavel[s]).c_str(), h[lavel[s] - 1].fontcolor, lavelfont);
					if (s != lavel.size() - 1) {
						if (lavel[s] > 9) {
							xx += fontsize * 2;
						}
						else {
							xx += fontsize;
						}
						xx += 2;
						DrawStringToHandle(xx, y + 13, string(" > ").c_str(), formcolor, lavelfont);
						xx += fontsize * 3 + 2;
						DrawBox(xx - 2, y + 11, xx + fontsize * ((lavel[s + 1] > 9) ? 2 : 1) + 5, y + 38, h[lavel[s + 1] - 1].backcolor, true);
					}
				}
			}
			break;
			}*/
			
		}
		//ALLBET�܂��͎��n�̕\��
		if (select > 0 && form != FORM::win && submenu == none) {
			switch (form) {
			case FORM::seq_conbi:
				DrawGraph(854, 3 + (select - 1) * mhei * 4, all, true);
			case FORM::conbi:
			case FORM::wide:
				DrawGraph(654, 3 + (select - 1) * mhei * 4, all, true);
				break;
			case FORM::triple:
			case FORM::seq_triple:
				DrawGraph(651, 1 + (select - 1) * mhei * 4, all, true);
				if (select2 > 0) {
					DrawGraph(651, 1 + (select2 - 1) * mhei * 4, all, true);
				}
				break;
			}			
		}
		//�T�u���j���[����{�^���󋵂̕\��
		if (submenu > none) {			
			for (auto f = touched.begin(); f != touched.end();f++) {				
				SetDrawBlendMode(DX_BLENDMODE_ADD, 200);
				DrawExtendGraph(f->x + 4, f->y + 5, f->x + f->wid - 4, f->y + f->hei - 6, subselect, true);				
				SetDrawBlendMode(DX_BLENDMODE_ALPHA, 100);
				DrawOval(f->x + f->wid / 2, f->y + f->hei / 2, f->wid / 2 - 4, f->hei / 2 - 5, h[f->num - 1].backcolor, true);
				SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 100);
			}
			if (displayed.size() > 0) {
				string s = to_string(displayed.size());
				int fs = GetFontSizeToHandle(lavelfont);
				DrawStringToHandle(1190 - (s.size() - 1) * fs, 555,s.c_str(),GetColor(255,255,255),lavelfont);
				DrawStringToHandle(1210, 555, "�_", GetColor(255, 255, 255), lavelfont);
				s = to_string(displayed.size() * chip);
				DrawStringToHandle(1190 - (s.size() - 1) * fs, 625, s.c_str(), GetColor(255, 255, 255), lavelfont);
			}
		}
	}		
	//�^�b�`���ꂽ�n���ɓq�������x�b�g����BBET�ɐ��������ꍇ��true���Ԃ�B
	bool bet(int x,int y,int chip, vector<baken*> &played) {
		if (form > FORM::top3 && form < FORM::triple) {
			int wid = 953;
			switch (form) {
			case FORM::conbi:
				wid = 850;
			case FORM::wide:
				if (x > 651 && x < wid && y > mhei * 4 * (select - 1) + 3 && y < mhei * 4 * select) {
					//ALLBET	
					auto bak = oddsdata.end();
					for (auto dis = displayed.begin(); dis != displayed.end(); dis++) {
						auto bak = GetBetOddsData(dis);
						if (bak->AddBET(chip)) {							
							if (bak != NULL) {
								dis->AddBET(chip);
								played.push_back(bak);
							}
						}
					}
					return true;
				}
				else {					
					//��BET
					return SingleBet(x, y, chip, played);
				}
				return false;
				break;
			case FORM::seq_conbi:
				if (y > mhei * 4 * (select - 1) + 3 && y < mhei * 4 * select) {
					//ALLBET
					auto dis = displayed.begin();
					vector<int>lavel;
					for (; dis != displayed.end(); dis++) {
						dis->GetData(lavel);
						if (x > 651 && x < 850) {
							//Select >
							if (lavel[0] == this->select) {
								auto bak = GetBetOddsData(dis);
								if (bak->AddBET(chip)) {									
									if (bak != NULL) {
										dis->AddBET(chip);
										played.push_back(bak);
									}
								}
							}
						}
						else {
							// > Select
							if (lavel[1] == this->select) {
								auto bak = GetBetOddsData(dis);
								if (bak->AddBET(chip)) {
									if (bak != NULL) {
										dis->AddBET(chip);
										played.push_back(bak);
									}
								}
							}
						}
					}
				}
				else {
					//��BET
					return SingleBet(x, y, chip, played);
				}
				break;
			}
		}
		else {
			return SingleBet(x, y, chip, played);
		}
		return false;
	}
	//��ʏ��1���̔n�����^�b�`�����Ƃ���BET�����B���������ꍇ��true���Ԃ�B
	bool SingleBet(int x,int y,int chip, vector<baken*>& played) {
		for (auto dis = displayed.begin(); dis != displayed.end(); dis++) {
			if (dis->Range(x, y)) {				
				auto bak = GetBetOddsData(dis);
				if (bak->AddBET(chip)) {
					if (bak != NULL) {
						dis->AddBET(chip);
						played.push_back(bak);
						return true;
					}
				}
			}
		}
		return false;
	}
	//�J�[�\������ʏ��1���̔n���͈͖̔��ɂ��邩�ǂ������m�F���Atrue�̏ꍇ�͂��̔n���̍�����W��Ԃ��B
	void SingleRange(const int mx, const int my, int& x, int& y) {
		int wid = 953;
		switch (form) {
		case FORM::conbi:
			wid = 850;
		case FORM::wide:
			if (mx > 651 && mx < wid && my > mhei * 4 * (select - 1) + 3 && my < mhei * 4 * select) {
				//ALLBET	
				x = 654;
				y = mhei * 4 * (select - 1) + 3;
				return;
			}
			break;
		case FORM::seq_conbi:
			if (my > mhei * 4 * (select - 1) + 3 && my < mhei * 4 * select) {
				//ALLBET
				x = 654;
				y = mhei * 4 * (select - 1) + 3;
				return;
			}			
			break;
		}
		for (auto dis = displayed.begin(); dis != displayed.end(); dis++) {
			if (dis->Range(mx, my)) {
				dis->GetData(x, y);
				return;
			}
		}
		x = 0;
		y = 0;
		return;
	}
	//BET�Ώۂ̔n���C�e���[�^�����̃|�C���^�ɕϊ��B�Ȃ������n�����Ώۂ̏ꍇ��FORM�𓯎��Ɏw�肷��B
	baken* GetBetOddsData(list<baken>::iterator bak) {
		vector<int> lavel;
		bak->GetData(lavel);
		int h = 0;
		for (int l = lavel.size() - 1, dec = 1; l > -1; l--, dec *= 100) {
			h += lavel[l] * dec;
		}
		int f;
		bak->GetFormToInt(f);
		if (f == 1) {
			h += 18;
		}
		if (FBFmap[h] != NULL) {
			return FBFmap[h];
		}
		else {
			return NULL;
		}
	}
	//�V���[�X�Ŋe��n���̃I�b�Y���v�Z����B
	void NewGame(const RACE race, const vector<HORSE>& horse, const int& font, const int& oddsfont) {
		select = 0;
		select2 = 0;
		hcount = race.horsecount;
		for (auto b = oddsdata.begin(); b != oddsdata.end(); b++) {
			b->DeleteBaken();
		}
		oddsdata.clear();
		displayed.clear();		
		oddsdata.shrink_to_fit();
		subpart = displayed.end();
		submenu = none;
		flow.clear();
		box.clear();
		forma.clear();
		int num = 1;
		for (int sb = 1; sb < 4; sb++) {
			num = 1;
			switch (sb) {
			case SUB::flow:
				for (unsigned int y = 1; y < horse.size() * mhei * 4; y += mhei * 4) {
					flow.emplace_back(653, y, 145, 50, num);
					flow.emplace_back(802, y, 145, 50, num);
					num++;
				}
				break;
			case SUB::box:
				for (unsigned int y = 1; y < horse.size() * mhei * 4; y += mhei * 4) {
					box.emplace_back(703, y,195,50, num);
					num++;
				}
				break;
			case SUB::formation:
				for (unsigned int y = 1; y < horse.size() * mhei * 4; y += mhei * 4) {
					if (form < FORM::triple) {
						forma.emplace_back(703, y, 75, 50, num);
						forma.emplace_back(822, y, 75, 50, num);
					}
					else {
						forma.emplace_back(653, y, 75, 50, num);
						forma.emplace_back(762, y, 75, 50, num);
						forma.emplace_back(872, y, 75, 50, num);
					}
					num++;
				}
				break;
			}			
		}				
		auto bakenp = bakendata.begin();
		double odds = 0;
		double modds = 0;
		double totalvalue = (double)(race.totalvalue);
		switch (form) {
		case FORM::win:
		{
			for (int h = 1; h < race.horsecount + 1; h++) {			
				bakenp = bakenmap[h];
				odds = (double)(floor(totalvalue / horse[h - 1].value * 10) / 10);
				modds = 0;
				oddsdata.emplace_back(bakenp, form, odds);				
			}
			double Big = 0, Small = 0;
			for (auto h = horse.begin(); h != horse.end(); h++) {
				if (h->rank == 1 || h->rank == 2) {
					Big += h->value;
				}
				if (h->rank == race.horsecount || h->rank == race.horsecount - 1) {
					Small += h->value;
				}
			}
			for (int h = 1; h < race.horsecount + 1; h++) {
				bakenp = bakenmap[h + race.horsecount];
				odds = (double)(floor((totalvalue - Big) / horse[h - 1].value / 3 * 10) / 10);
				modds = (double)(floor((totalvalue - Small) / horse[h - 1].value / 3 * 10) / 10);
				if (odds > 99) {
					odds = 99;
				}
				if (modds > 99) {
					modds = 99;
				}
				oddsdata.emplace_back(bakenp, FORM::top3, odds, modds);
			}
			//copy(oddsdata.begin(), oddsdata.end(), back_inserter(displayed));
			odds = 0;
			break;
		}		
		case FORM::conbi:
		{
			for (int h = 1; h < race.horsecount; h++) {				
				for (int hh = h + 1; hh < race.horsecount + 1; hh++) {					
					bakenp = bakenmap[h * 100 + hh];
					odds = (double)((totalvalue / horse[h - 1].value * (totalvalue - horse[h - 1].value) / horse[hh - 1].value) / 2);
					oddsdata.emplace_back(bakenp, form, odds);
				}
			}
		}
			break;
		case FORM::seq_conbi:
		{
			for (int h = 1; h < race.horsecount + 1; h++) {				
				for (int hh = 1 ; hh < race.horsecount + 1; hh++) {
					if (h != hh) {						
						bakenp = bakenmap[h * 100 + hh];
						odds = (double)(totalvalue / horse[h - 1].value * (totalvalue - horse[h - 1].value) / horse[hh - 1].value);
						if (odds > 99999) {
							odds = 99999;
						}
						oddsdata.emplace_back(bakenp, form, odds);
					}
				}
			}
		}
			break;
		case FORM::wide:
		{
			double Big = 0, Small = 0;
			double bs;
			for (auto h = horse.begin(); h != horse.end(); h++) {
				if (h->rank == 1 || h->rank == 2) {
					Big += h->value;
				}
				if (h->rank == race.horsecount || h->rank == race.horsecount - 1) {
					Small += h->value;
				}
			}
			double Btotal = totalvalue - Big;
			double Stotal = totalvalue - Small;
			for (int h = 1; h < race.horsecount; h++) {
				
				for (int hh = h + 1; hh < race.horsecount + 1; hh++) {
					
					bakenp = bakenmap[h * 100 + hh];
					odds = (double)(floor(Btotal / horse[h - 1].value * (Btotal - horse[h - 1].value) / horse[hh - 1].value + Btotal / horse[hh - 1].value * (Btotal - horse[hh - 1].value) / horse[h - 1].value) / race.horsecount);
					modds = (double)(floor(Stotal / horse[h - 1].value * (Stotal - horse[h - 1].value) / horse[hh - 1].value + Stotal / horse[hh - 1].value * (Stotal - horse[hh - 1].value) / horse[h - 1].value) / race.horsecount);
					odds = (double)(floor(odds * 10) / 10);
					modds = (double)(floor(modds * 10) / 10);
					bs = modds - odds;
					odds = modds;
					modds += bs;
					if (odds > 9999) {
						odds = 9999;
					}
					if (modds > 9999) {
						modds = 9999;
					}
					oddsdata.emplace_back(bakenp, form, odds,modds);
				}
			}
		}
			break;
		case FORM::triple:
		{
			for (int h = 1; h < race.horsecount - 1; h++) {				
				for (int hh = h + 1; hh < race.horsecount; hh++) {					
					for (int hhh = hh + 1; hhh < race.horsecount + 1; hhh++) {						
						bakenp = bakenmap[h * 10000 + hh * 100 + hhh];
						odds = (double)((totalvalue / (horse[h - 1].value) * (totalvalue - (horse[h - 1].value)) / (horse[hh - 1].value) * (totalvalue - (horse[h - 1].value) - (horse[hh - 1].value)) / (horse[hhh - 1].value)) / 6);
						odds = (double)(floor(odds * 10) / 10);
						if (odds > 99999) {
							odds = 99999;
						}
						oddsdata.emplace_back(bakenp, form, odds);
					}
				}
			}
		}
			break;
		case FORM::seq_triple:
		{
			for (int h = 1; h < race.horsecount + 1; h++) {								
				for (int hh = 1; hh < race.horsecount + 1; hh++) {					
					for (int hhh = 1; hhh < race.horsecount + 1; hhh++) {						
						if (h != hh && h != hhh && hh != hhh) {	
							bakenp = bakenmap[h * 10000 + hh * 100 + hhh];
							odds = (double)(totalvalue / (horse[h - 1].value) * (totalvalue - (horse[h - 1].value)) / (horse[hh - 1].value) * (totalvalue - (horse[h - 1].value) - (horse[hh - 1].value)) / (horse[hhh - 1].value));
							odds = (double)(floor(odds * 10) / 10);
							if (odds > 99999) {
								odds = 99999;
							}
							oddsdata.emplace_back(bakenp, form, odds);
						}
					}
				}
			}
		}
			break;
		}
		odds = 0;
		vector<int> lav;
		int h;
		for (auto d = oddsdata.begin(); d != oddsdata.end(); d++) {
			d->CreateBakenGraph(horse, bimg,font, oddsfont);						
			if (form >= FORM::conbi) {
				d->GetData(lav);
				h = 0;
				for (int l = lav.size() - 1, dec = 1; l > -1; l--, dec *= 100) {
					h += lav[l] * dec;
				}
				FBFmap[h] = &*d;
			}
			else {
				int f;
				d->GetFormToInt(f);
				d->GetData(lav);
				if (FORM(f) == FORM::win) {
					FBFmap[lav[0]] = &*d;
				}
				else {
					FBFmap[lav[0] + 18] = &*d;
				}
			}
		}
	}
	//menu���ɂ���oddsdata�Ǝ������ʂ��ƍ����A���I����baken����Ԃ��B
	void GetHitBakenInfo(const vector<int> &lavel,int &bet) {
		for (auto bak = oddsdata.begin(); bak != oddsdata.end(); bak++) {
			if (bak->result(lavel[0], lavel[1], lavel[2])) {				
				bak->GetData(bet);
				double bodds, sodds;
				bak->GetOdds(bodds, sodds);
				return;
			}
		}
	}
	void GetHitBakenInfo(const vector<int>& lavel,int& bet ,double& odds ) {
		for (auto bak = oddsdata.begin(); bak != oddsdata.end(); bak++) {
			if (bak->result(lavel[0], lavel[1], lavel[2])) {
				odds = bak->GetOdds();
				bak->GetData(bet);
				return;
			}
		}
	}
	void GetHitBakenInfo(const vector<int>& lavel, int& bet,FORM f) {
		for (auto bak = find(oddsdata.begin(),oddsdata.end(),FORM::top3); bak != oddsdata.end(); bak++) {
			if (bak->result(lavel[0], lavel[1], lavel[2])) {
				bak->GetData(bet);
				return;
			}
		}
	}
	//���ݕ\������Ă��郁�j���[�̏󋵂�Ԃ��B0.�ʏ��� 1.������ʁ@2.�{�b�N�X��ʁ@3.�t�H�[���[�V�������
	SUB GetNowMenu() {
		return submenu;
	}
	int GetSelect2() {
		return select2;
	}
	void SetSelect(int s1, int s2) {
		select = s1;		
		if (submenu == none) {
			if (form < FORM::triple) {
				select2 = 0;
				SetMainHorse(s1);
			}
			else {
				select2 = s2;
				SetMainHorse(s1, s2);
			}
		}
	}
	//�P���E�������j���[���ĕ\�����ꂽ�Ƃ���oddsdata����displayed�ɔn���f�[�^���R�s�[����B
	void SetWinOdds() {
		displayed.clear();
		for (auto b = oddsdata.begin(); b != oddsdata.end(); b++) {
			displayed.push_back(*b);
		}
		int count = 1;
		int y = 3;
		for (auto h = displayed.begin(); h != displayed.end(); h++, count++,y += mhei * 4) {
			if (count > hcount) {
				h->SetDisplayed(854,y);
			}
			else {
				h->SetDisplayed(654, y);
			}
			if (count == hcount) {
				y = 3 - mhei * 4;
			}
		}
	}
	//���j���[�̏󋵂�ύX����B���̎����݊J����Ă���T�u���j���[�������ƈ�v����ꍇ�ʏ��ʂɖ߂�܂��B
	void SetNowMenu(SUB s) {
		auto premenu = submenu;
		if (form == FORM::win) {
			submenu = none;
		}
		else {
			submenu = s;
		}
		if (submenu > SUB::none) {
			displayed.clear();
			touched.clear();
			subpart = displayed.end();
		}
		else {
			if (premenu > SUB::none) {
				//�\���n���̍Č���
				displayed.clear();
				if (form > FORM::wide) {					
					SetMainHorse(select, select2);
				}
				else {
					SetMainHorse(select);
				}
			}
		}
	}
	//���n���w�肷��B���̎��O�A���E�O�A�P�̏ꍇ����select > 0�̎���select2�ɐݒ肵�A�����ꂩ�I�𒆂̎��n�ɍă^�b�`���ꂽ�ꍇ�͑I������������B
	void SetMainHorse(int s1) {				
		if (s1 > 0 && form >= FORM::conbi) {	
			select = s1;
			displayed.clear();
			for (auto baken = oddsdata.begin(); baken != oddsdata.end(); baken++) {
				switch (form) {
					//�P���E�����͎��n�̑I���ɂ�����炸�\�������n���ɕω��Ȃ�
				case FORM::conbi:
				case FORM::wide:
					if (baken->Contain(s1)) {
						displayed.push_back(*baken);
					}
					break;
				case FORM::seq_conbi:
					if (baken->Contain(s1, 0)) {						
						displayed.push_back(*baken);
					}
					if (baken->Contain(0, s1)) {						
						displayed.push_back(*baken);
					}
					break;
				}
			}
			unsigned int count = 1;
			vector<int> lavel;
			auto dis = displayed.begin();
			for (int x = 654, y = (select == 1) ? 3 + mhei * 4 : 3 ; dis != displayed.end();) {
				dis->GetData(lavel);
				switch (form) {
				case FORM::conbi:
				case FORM::wide:
					dis->SetDisplayed(x, y);
					if (lavel[0] + 1 == select) {
						y += mhei * 4;
					}
					dis++;
					y += mhei * 4;
					break;
				case FORM::seq_conbi:
					if (select != lavel[0]) {
						dis->SetDisplayed(x + 200, y);
						y += mhei * 4;
						if (select > lavel[0]) {														
							if (select - lavel[0] == 1) {
								y = 3;
							}
						}						
					}
					else {
						//select == lavel[0]
						dis->SetDisplayed(x, y);
						y += mhei * 4;
						if (select - lavel[1] == 1) {
							y = mhei * 4 * select + 3;
						}
						if (lavel[1] == hcount) {
							y = mhei * 4 * select + 3;
						}
						
					}
					dis++;
					break;
				}
			}
		}
	}
	void SetMainHorse(int s1,int s2) {
		displayed.clear();
		select = s1;
		if (select == 0) {
			select = select2;
			select2 = 0;
		}
		else {
			select2 = s2;
		}
		if (select > 0 && select2 > 0 && form >= FORM::conbi) {			
			for (auto baken = oddsdata.begin(); baken != oddsdata.end(); baken++) {
				switch (form) {
				case FORM::triple:
				case FORM::seq_triple:
					if (baken->Contain(select, select2)) {						
						displayed.push_back(*baken);
					}
					break;
				}
			}
			unsigned int count = 1;
			vector<int> lavel;
			auto dis = displayed.begin();
			int y = 3;
			if (select == 1) {
				if (select2 == 2) {
					y += mhei * 4;
				}
				y += mhei * 4;
			}
			if (select2 == 1) {
				if (select == 2) {
					y += mhei * 4;
				}
				y += mhei * 4;
			}
			for (int  x = 654; dis != displayed.end();) {
				dis->GetData(lavel);
				dis->SetDisplayed(x, y);
				if (form == FORM::triple) {
					if ((select - select2) == 1 || (select - select2) == -1) {
						if ((lavel[0] + 1 == select || lavel[0] + 1 == select2) &&
							(lavel[2] == select || lavel[2] == select2)) {
							y += mhei * 8;
						}
					}
					else {
						if (select < select2) {
							if (lavel[0] + 1 == select) {
								y += mhei * 4;
							}
							if (lavel[1] + 1 == select2) {
								y += mhei * 4;
							}
						}
						else {
							if (lavel[0] + 1 == select2) {
								y += mhei * 4;
							}
							if (lavel[1] + 1 == select) {
								y += mhei * 4;
							}
						}
					}
				}
				else {
					if (lavel[2] + 1 == select) {
						y += mhei * 4;
						if (lavel[2] + 2 == select2) {
							y += mhei * 4;
						}
					}
					if (lavel[2] + 1 == select2) {
						y += mhei * 4;
						if (lavel[2] + 2 == select) {
							y += mhei * 4;
						}
					}
				}
				dis++;
				y += mhei * 4;
			}
		}
	}
	//�T�u���j���[�W�J���Ƀ^�b�`���ꂽ�ꏊ����flow,box,forma�𑀍삷��B���֌W�ȏꏊ�������ꍇ��false���Ԃ�B
	bool SetSubSelect(int x, int y) {
		auto begin = flow.begin(), end = flow.end();
		bool ope = false;
		switch (submenu) {
		case 1://flow
			break;
		case 2://box
			begin = box.begin();
			end = box.end();
			break;
		case 3://formation
			begin = forma.begin();
			end = forma.end();
			break;
		}
		for (; begin != end; begin++) {
			if (begin->x <= x && x < begin->x + begin->wid && begin->y <= y && y < begin->y + begin->hei) {
				auto dis = find(touched.begin(), touched.end(), *begin);
				if (dis != touched.end()) {
					//�I��������
					touched.erase(dis);
				}
				else {
					//�I����ݒ�
					switch(submenu) {
					case SUB::flow:
						if (begin->x == 653){
							if (!FlowLimit()) {
								touched.push_back(*begin);
							}
						}
						else {
							if (form == FORM::seq_triple && submenu == SUB::flow) {
								if (!FlowLimitR()) {
									touched.push_back(*begin);
								}
							}
							else {
								touched.push_back(*begin);
							}
						}
						break;
					case SUB::box:
						if (!BoxLimit()) {
							touched.push_back(*begin);
						}
						break;
					case SUB::formation:
						touched.push_back(*begin);
						break;
					}
					
				}
				ope = true;
				break;
			}
		}
		//����sort�ɂ��I�����ꂽFBF�͑S�ď���(��1 < ��2 < ��3)�Ɠ����ɔn�ԍ��̏����ɂȂ�B
		sort(touched.begin(), touched.end());
		FBFSort();
		return ope;
	}
	//�I�b�Y��(true)�܂��͔n�ԍ���(false)��FBF��̔n�������ւ��ĕ\������B
	void SetFBFDisplay(bool odds) {
		oddsnum = odds;
		FBFSort();
	}
	//�J�[�\����FBF�̑I���{�^���ɂ��邩�ǂ����𒲂ׁA�͈͓��̏ꍇ�͍���ƉE���̍��W��Ԃ��B
	void GetFBFRange(const int& mx, const int& my, int& x1, int& y1, int& x2, int& y2) {
		auto begin = flow.begin(), end = flow.end();
		switch (submenu) {
		case 1://flow
			break;
		case 2://box
			begin = box.begin();
			end = box.end();
			break;
		case 3://formation
			begin = forma.begin();
			end = forma.end();
			break;
		}
		for (; begin != end; begin++) {
			if (begin->x <= mx && mx < begin->x + begin->wid && begin->y <= my && my < begin->y + begin->hei) {
				x1 = begin->x;
				y1 = begin->y;
				x2 = x1 + begin->wid;
				y2 = y1 + begin->hei;
				return;
			}
		}
		x1 = 0;
		y1 = 0;
	}
	//�T�u���j���[�W�J���̔n����touched�̏󋵂ɉ�����displayed�ɐݒ肷��BSetSubSelect�܂���SetFBFDisplay����Ăяo�����B
	void FBFSort() {
		displayed.clear();
		
		int formsub = form * 10 + submenu;
		vector<vector<FBF>::iterator> lavel = { touched.begin(),touched.end(),touched.end() };
		if (formsub < 50) {
			lavel.pop_back();
		}
		auto second = touched.begin();
		/*
		flow  653 802
		box   703
		forma 703 822
		forma 653 762 872
		*/
		if (touched.size() < 2 || (formsub >= 50 && touched.size() < 3) ){
			formsub = 0;
		}
		switch (formsub) {
		case 21://conbi flow
		case 31://seq_conbi flow
		case 41://wide flow			
			if (lavel[0]->x == 653) {
				second += 1;
				for (; second != touched.end(); second++) {
					lavel[1] = second;
					FBFBakenSelect(lavel);
				}
			}
			break;
		case 22://conbi box		
		case 42://wide box
			for (auto first = touched.begin(); first != touched.end() - 1; first++) {
				for (second = first + 1; second != touched.end(); second++) {
					lavel[0] = first;
					lavel[1] = second;
					FBFBakenSelect(lavel);
				}
			}
			break;
		case 23://conbi forma
		case 33://seq_conbi forma
		case 43://wide forma
			second = find(touched.begin(), touched.end(), 822);
			for (auto first = touched.begin(); first < second; first++) {
				for (auto sec = second; sec != touched.end(); sec++) {
					lavel[0] = first;
					lavel[1] = sec;
					FBFBakenSelect(lavel);
				}
			}
			break;
		case 32://seq_conbi box
			for (auto first = touched.begin(); first != touched.end(); first++) {
				for (second = touched.begin(); second != touched.end(); second++) {
					lavel[0] = first;
					lavel[1] = second;
					FBFBakenSelect(lavel);
				}
			}
			break;
		case 51://triple flow
			second = touched.begin() + 1;
			if (second->x == 653) {
				//2���̎��n�𒆐S�Ƃ��ė�����ݒ�
				lavel[1] = touched.begin() + 1;
				for (second = touched.begin() + 2; second != touched.end(); second++) {
					lavel[2] = second;
					FBFBakenSelect(lavel);
					//swap(lavel[0], lavel[1]);
				}
			}
			else {
				//1���̎��n�𒆐S�Ƃ��ė�����ݒ�
				for (; second != touched.end() - 1; second++) {
					for (auto third = second + 1; third != touched.end(); third++) {
						lavel[1] = second;
						lavel[2] = third;
						FBFBakenSelect(lavel);
					}
				}
			}
			break;
		case 61://seq_triple flow
			second = touched.begin() + 1;
			if (second->x == 653) {
				//2���̎��n�𒆐S�Ƃ��ė�����ݒ�				
				for (second = touched.begin() + 2; second != touched.end(); second++) {
					lavel[0] = touched.begin();
					lavel[1] = touched.begin() + 1;
					lavel[2] = second;//0-1-2
					FBFBakenSelect(lavel);
					swap(lavel[0], lavel[1]);//1-0-2
					FBFBakenSelect(lavel);
					swap(lavel[0], lavel[2]);//2-0-1					
					FBFBakenSelect(lavel);
					swap(lavel[0], lavel[1]);//0-2-1					
					FBFBakenSelect(lavel);
					swap(lavel[0], lavel[2]);//1-2-0					
					FBFBakenSelect(lavel);
					swap(lavel[0], lavel[1]);//2-1-0					
					FBFBakenSelect(lavel);
				}
			}
			else {
				//1���̎��n�𒆐S�Ƃ��ė�����ݒ�
				for (int f = 1; f < 4; f++) {
					for (second = touched.begin() + 1; second != touched.end() - 1; second++) {
						for (auto third = touched.begin() + 1; third != touched.end(); third++) {
							switch (f) {
							case 1://1��
								lavel[1] = second;
								lavel[2] = third;
								FBFBakenSelect(lavel);
								lavel[2] = second;
								lavel[1] = third;
								FBFBakenSelect(lavel);
								break;
							case 2://2��
								lavel[1] = touched.begin();
								lavel[0] = second;
								lavel[2] = third;
								FBFBakenSelect(lavel);
								lavel[2] = second;
								lavel[0] = third;
								FBFBakenSelect(lavel);
								break;
							case 3://3��
								lavel[2] = touched.begin();
								lavel[1] = second;
								lavel[0] = third;
								FBFBakenSelect(lavel);
								lavel[0] = second;
								lavel[1] = third;
								FBFBakenSelect(lavel);
								break;
							}

						}
					}
				}
			}
			break;
		case 52://triple box		
			for (auto first = touched.begin(); first != touched.end() - 2; first++) {
				for (second = first + 1; second != touched.end() - 1; second++) {
					for (auto third = second + 1; third != touched.end(); third++) {
						lavel[0] = first;
						lavel[1] = second;
						lavel[2] = third;
						FBFBakenSelect(lavel);
					}
				}
			}
			break;
		case 62://seq_triple box
			for (auto first = touched.begin(); first != touched.end(); first++) {
				for (second = touched.begin(); second != touched.end(); second++) {
					for (auto third = touched.begin(); third != touched.end(); third++) {
						if (first != second && first != third && second != third) {
							lavel[0] = first;
							lavel[1] = second;
							lavel[2] = third;
							FBFBakenSelect(lavel);
						}
					}
				}
			}
			break;
		case 53://triple forma
		case 63://seq_triple forma
		{
			for (auto first = find(touched.begin(), touched.end(), 653); first != touched.end() && first->x == 653; first++) {
				for (second = find(touched.begin(), touched.end(), 762); second != touched.end() && second->x == 762; second++) {
					for (auto third = find(touched.begin(), touched.end(), 872); third != touched.end(); third++) {
						if (first != second && first != third && second != third) {
							lavel[0] = first;
							lavel[1] = second;
							lavel[2] = third;
							FBFBakenSelect(lavel);
						}
					}
				}
			}
		}
			break;
		}
		if (!oddsnum) {
			displayed.sort();
		}
		if (displayed.size() > 0) {
			//�\���pbaken�Ɣ�\����oddsdata��baken�Ƃ̋�ʉ�
			int x = (form < FORM::wide) ? 1004 : 954;
			int y = 3 + mhei * 4;
			for (auto dis = displayed.begin(); dis != displayed.end(); dis++) {
				dis->SetDisplayed(x, y);
				y += mhei * 4;
			}
			subpart = displayed.begin();			
		}
		else {
			subpart = displayed.end();
		}
	}
	//�T�u���j���[����ɂ���Đ������Ώ۔n���̔���
	void FBFBakenSelect(vector<vector<FBF>::iterator> &lv) {
		int h = 0;
		vector<vector<FBF>::iterator> lavel(lv);
		switch (form) {
		case FORM::conbi:
		case FORM::wide:
		case FORM::triple:
			sort(lavel.begin(), lavel.end(),FBFS);
			break;
		}
		for (int l = lavel.size() - 1, dec = 1; l > -1; l--, dec *= 100) {
			
			h += lavel[l]->num * dec;
		}
		auto bak = FBFmap[h];
		if (bak != NULL) {
			//�Ώ۔n���̑g�ݍ��킹��oddsdata���猩�������Ƃ�
			if (find(displayed.begin(), displayed.end(), bak) == displayed.end()) {
				//�Ώ۔n�����\���ΏۂƔ���Ă��Ȃ��Ƃ�
				if (oddsnum) {
					auto begin = displayed.begin();					
					switch (displayed.size()) {
					case 0:
						displayed.push_back(*bak);
						break;
					case 1:
						if (begin->GetOdds() < bak->GetOdds()) {
							displayed.push_back(*bak);
						}
						else {
							displayed.push_front(*bak);
						}
						break;
					default:
					{
						auto end = displayed.end();
						end--;						
						if (bak->GetOdds() < begin->GetOdds()) {
							displayed.push_front(*bak);
							
						}
						else {
							if (bak->GetOdds() > end->GetOdds()) {
								displayed.push_back(*bak);
							}
							else {
								//begin < bak < end
								while (bak->GetOdds() > begin->GetOdds() ||  bak->GetOdds() < end->GetOdds()) {
									begin++;
									end--;
								}
								
								if (end->GetOdds() < bak->GetOdds()) {									
									while (end->GetOdds() < bak->GetOdds()) end++;									
									displayed.insert(end, *bak);									
								}
								else {
									while (begin->GetOdds() > bak->GetOdds()) begin--;
									displayed.insert(--begin, *bak);									
								}
							}
						}
					}
					break;
					}
				}
				else {
					displayed.push_back(*bak);					
				}
			}
		}
	}
	//�T�u���j���[�W�J���ɕ\������Ă���n���̏㉺�ɂ���{�^������A�\������n���𑀍삷��B
	void FBFSelect(bool up) {
		auto prepart = subpart;
		if (up) {
			if (subpart != displayed.begin()) {
				//�\���n���̌J�グ
				subpart--;
			}
		}
		else {
			int hachi = 1;
			auto sub = subpart;
			for(;hachi < 9 && sub != displayed.end();hachi++,sub++){}
			if (sub != displayed.end()) {
				//�\���n����8�ȏ゠��A���Ō�ȏ�ɕ\������Ȃ��ꍇ�A�\���n���̌J�艺��
				subpart++;
			}
		}
		if (prepart != subpart) {
			//�\�����삪�������ꍇ�A�\���ʒu�̍Ē���
			int x = (form < FORM::wide) ? 1004 : 954;
			int y = 3 + mhei * 4;
			for (auto dis = subpart; dis != displayed.end(); dis++) {
				dis->SetDisplayed(x, y);
				y += mhei * 4;
			}
		}
	}
	//flow�ɂč����{�^��(���n)������ȏ�I���ł��Ȃ����𔻒f����B
	bool FlowLimit() {
		if (form < FORM::triple) {
			return (count(touched.begin(), touched.end(), 653) >= 1);
		}
		else {
			return (count(touched.begin(), touched.end(), 653) >= 2);
		}
	}
	//flow����seq_triple�ɂĎ��n��1���̎��A�΍R�n(�E��)��5���ȏ�I���ł��Ȃ����𔻒f����
	bool FlowLimitR() {
		if (form != FORM::seq_triple || submenu != SUB::flow || touched.size() < 3 || touched[1].x == 653) {
			return false;
		}
		int right = count(touched.begin() + 1, touched.end(),802);
		if (right >= 5) {
			return true;
		}		
		return false;
	}
	//flow�ɂĎw�肵��������W�ɂ���I���{�^�����I�𒆂��ǂ����𔻒f����B
	bool FlowLimit(int x, int y) {
		FBF fbf(x,y);
		if (submenu != SUB::flow || touched.size() == 0) {
			return false;
		}
		if (find(touched.begin(), touched.end(), fbf) != touched.end()) {
			return true;
		}
		else {
			return false;
		}
	}
	//box�ɂă{�^�������ȏ�I���ł��Ȃ����ǂ����𔻒f����B
	bool BoxLimit() {		
		if (submenu == SUB::box) {			
			if (touched.size() == 7) {
				return true;
			}
		}
		return false;
	}
	//�T�u���j���[�őI�����ꂽ�S�Ă̔n����BET����BBET���ɃN���W�b�g������Ȃ��Ȃ�ꍇ�͈ꗗ�̏������珇�ɂł������BET����B
	void FBFAllBet(const int &credit,const int &chip, vector<baken*>& checking) {
		if (submenu > none && displayed.size() > 0) {						
			vector<int> lavel;
			int total = 0;
			for (auto dis = displayed.begin(); dis != displayed.end(); dis++) {				
				if (credit - total < 0) {
					break;
				}
				auto bak = GetBetOddsData(dis);
				if (bak != NULL) {
					if (bak->AddBET(chip)) {						
						total += chip;
						dis->AddBET(chip);
						checking.push_back(bak);
					}
				}
			}
		}
	}	
	
	
	const FORM form;
private:	
	vector<bakenlavel>bakendata;//�S�g�ݍ��킹�n���̑S�f�[�^�BMenu�̃R���g���N�^�ɂĐݒ肳���B
	map<int, vector<bakenlavel>::iterator> bakenmap;//bakendata�ւ̃C�e���[�^�𐔒l�Ō������邽�߂�map�B
	vector<baken> oddsdata;//�e�n���`�����Ƃ̑S�I�b�Y�f�[�^�BNewGame�ɂĐݒ肳���B�܂�bakendata�ւ̃|�C���^���ݒ肳���B
	map<int, baken*>FBFmap;//FBF����oddsdata��baken���������邽�߂�map�B
	int select;//���n�B�P���E�����ł�0�ɂȂ�B
	int select2;//���n2�B�O�A���A�O�A�P�ɂė��p����邪�A����ȊO��0�ƂȂ�B
	bool oddsnum;//�T�u���j���[�W�J���ɕ\�������n�����I�b�Y���ɕ\��(=true)���邩�n�ԍ����ɕ\��(=false)���邩��������B
	int hcount;//�����n���BNewGame�ɂĐݒ肳���B
	list<baken> displayed;//���ݕ\���ΏۂƂȂ��Ă���n���B�P���E�����ł͗��p����Ȃ��B�܂��T�u���j���[�ł�subpart��!=displayed.end()�ƂȂ�B
	list<baken>::iterator subpart;//�T�u���j���[�ɂĕ\�����E�ƂȂ�n���̃C�e���[�^�B��������++8�܂ł��\���ΏۂƂȂ�B�ʏ��ʂł� == displayed.end()�ƂȂ�B
	const int bimg;//���j���[�ɂĕ\�������n���摜�B�R���X�g���N�^����w��̉摜���󂯎��B
	int bakenimg;//�n���̑g�ݍ��킹�ƃI�b�Y�摜�BNewGame�̓x�ɍ�蒼�����BFBF���ɂ͎g��ꂸ�Aoddsdata���̉摜���g����B
	const int all;//ALLBET�̃{�^���摜�B�K�v�̂Ȃ��ꍇ��0���󂯓n�����B
	SUB submenu;//���j���[�̏�ԁB0.�ʏ��� 1.������ʁ@2.�{�b�N�X��ʁ@3.�t�H�[���[�V�������	
	vector<FBF> flow;
	vector<FBF>box;
	vector<FBF> forma;
	vector<FBF> touched;//flow,box,forma����push_back����邱�ƂőI������Ă��邱�Ƃ������B
};

class Home {
	
public:	
	Home() {			
		
		const int allimg = LoadGraph("data/allbet.png");//ALLBET�{�^���摜�B
		const int sallimg = LoadGraph("data/sanallbet.png");//���C�hALLBET�{�^���摜�B
		const int sanmain = LoadGraph("data/sanmain.png");//�O�A���E�O�A�P���n�{�^���摜�B				
		for (auto m : FORM()) {
			if (m != FORM::top3) {
				switch (m) {
				case FORM::wide:
					betmenu.emplace_back(m, sbimg, sallimg);
					break;
				case FORM::triple:
				case FORM::seq_triple:
					betmenu.emplace_back(m, sbimg, sanmain);
					break;
				default:
					betmenu.emplace_back(m, bimg, allimg);
					break;
				}

			}
		}
		int s[FBFcancel + 1][4] = {//x1 x2,y1,y2
			{1,1250,837,910},//menuber
			{1,450,1,845},//horse
			{451,650,1,845},//info
			{651,850,1,845},//bet1 or info2(home�̂�)
			{851,1050,1,845},//bet2 or info3(home�̂�)
			{1261,1440,27,195},//start �o�[�W�����ɂ���Ă͎c�莞��			
			{1258,1437,518,593},//betrate
			{1265,1437,623,672},//Undo
			{1265,1437,686,735},//betlist
			{1053,1247,732,828},//option
			{1265,1437,741,909},//End		
			{1065,1240,535,613},//flow
			{1065,1240,639,717},//box
			{1065,1240,746,823},//forma			
			{461,950,1,845},//FBFplot
			{961,1250,56,468},//FBFbaken
			{1015,1200,53,53},//FBFup			
			{1015,1200,469,469},//FBFdown
			{1054,1245,527,732},//FBFAllbet
			{961,1045,521,735},//FBFoddsnum
			{1065,1240,746,823},//FBFcancel			
			
		};
		for (int b = 0; b < FBFcancel + 1; b++) {	
			if (BNAME(b) == BNAME::up) {
				button.emplace_back(s[b][0], s[b][1], s[b][2], s[b][3], 1100, 1, BNAME(b));
			}
			else {
				if (BNAME(b) == down) {
					button.emplace_back(s[b][0], s[b][1], s[b][2], s[b][3], 1100, 520, BNAME(b));
				}
				else {
					button.emplace_back(s[b][0], s[b][1], s[b][2], s[b][3], BNAME(b));
				}
			}
			
		}
		int bls[16][4] = {
			{110,77,25,0},//winup
			{320,77,25,0},//top3up
			{530,77,25,0},//conbiup
			{740,77,25,0},//seq_conbiup
			{1025,77,25,0},//wideup
			{180,77,25,0},//tripleup
			{535,77,25,0},//seq_tripleup
			{110,790,25,0},//windown
			{320,790,25,0},//top3down
			{530,790,25,0},//conbidown
			{740,790,25,0},//seq_conbidown
			{1025,700,25,0},//widedown
			{180,700,25,0},//tripledown
			{535,790,25,0},//seq_tripledown
			{937,1190,764,813},//triple
			{52,295,764,813},//winwide
		};
		for (int b = 0; b < 16; b++) {
			if (bls[b][3] == 0) {
				betlistbutton.emplace_back(bls[b][0], bls[b][1], bls[b][2]);
			}
			else {
				betlistbutton.emplace_back(bls[b][0], bls[b][1], bls[b][2], bls[b][3], BNAME(0));
			}
		}
		int data = 0;
		char d[50];
		data = FileRead_open("data/horse.txt");
		HORSENAME hname;
		while (FileRead_eof(data) == false) {
			FileRead_gets(d, 50, data);
			hname.name = string(d);
			hname.use = false;
			horsename.push_back(hname);
		}
		FileRead_close(data);
		Load();
		configback = MakeGraph(1449, 909);
		vector<string>soundname = {
			"select",//�x�b�g���j���[����A�n�I���A�n���A���[�X�J�n�A�I��
			"bet",//�ʏ�y��FBF�ł̌ʃx�b�g
			"Allbet",//�ʏ�y��FBF�ł�ALL�x�b�g
			"Info",//�n���E�n�I��
			"betmenu",//BET�ꗗ�ł̑���S��
			"FBFplot",//FBF�{�^���N���b�N�AFBF���쓙
			"cancel",//���߂��AFBF����ʏ�֖߂鎞
			"win"
		};
		
		for (int s = SOUND::SEselect; s < SEwin + 1; s++) {
			string name = "data/BGM�ESE/" + soundname[s] + ".mp3";
			Sound.push_back(LoadSoundMem(name.c_str()));
			ChangeVolumeSoundMem((Player.SEVolume == 10) ? 255 : Player.SEVolume * 26, Sound[s]);
		}
		
		for (int m = 0; m < 4; m++) {
			//ChangeVolumeSoundMem((Player.SEVolume == 10) ? 255 : Player.SEVolume * 26, *Music[m]);
		}
		font.horseinfo = CreateFontToHandle("MS P�S�V�b�N", 28, 6, -1, -1, 2);
		font.baken = CreateFontToHandle("MS �S�V�b�N", 24, 2);
		font.odds = CreateFontToHandle("MS �S�V�b�N", 16, 6,DX_FONTTYPE_EDGE,-1,2);
		font.record = CreateFontToHandle("MS �S�V�b�N", 14, 3, DX_FONTTYPE_EDGE, -1, 1);
		font.result = CreateFontToHandle("MS �S�V�b�N", 20, 3, DX_FONTTYPE_EDGE, -1, 2);
		Mouse.click = 0;
		Mouse.clickbutton = MOUSE_INPUT_LEFT;
		Mouse.clicklog = MOUSE_INPUT_LOG_UP;
		Mouse.x = 0;
		Mouse.y = 0;
		this->horse.clear();		
	}
	~Home() {
	}
	void Load() {
		ifstream file("data/playerdata.txt");
			
		if (!file.is_open()) {
			Player.cash = 1000;
			Player.ID = GetRand(1000000);			
			Player.chip = BetRate.begin();
			Player.name = "";
			Player.BGMVolume = 5;
			Player.SEVolume = 5;
			Player.maxconbo = 1;
			Player.maxwin = 100;
		}
		else {	
			//file.open("data/playerdata.txt", ios::in);
			string input;
			getline(file, input);
			Player.cash = atoi(input.c_str());
			getline(file, input);
			Player.chip = find(BetRate.begin(), BetRate.end(), atoi(input.c_str()));
			if (Player.chip == BetRate.end()) {
				Player.chip = BetRate.begin();
			}
			getline(file, input);
			Player.ID = atoi(input.c_str());	
			getline(file, input);
			Player.BGMVolume = atoi(input.c_str());
			getline(file, input);
			Player.SEVolume = atoi(input.c_str());
			getline(file, input);
			Player.maxconbo = atoi(input.c_str());
			getline(file, input);
			Player.maxwin = atoi(input.c_str());
			//getline(file, input);
			//Player.name = input;
		}
		
		Player.totalbet = 0;
		Player.win = 0;
		Player.conbo = 0;
		file.close();
	}
	void Save() {
		ofstream file;
		file.open("data/playerdata.txt", ios::out);
		file << Player.cash << endl;		
		file << *Player.chip << endl;
		file << Player.ID << endl;
		file << Player.BGMVolume << endl;
		file << Player.SEVolume << endl;
		file << Player.maxconbo << endl;
		file << Player.maxwin << endl;
		//file << Player.name << endl;
		file.close();
	}
	//���j���[��\��
	void DisplayMenu() {
		int color;
		if (nowmenu == betmenu.end()) {
			color = GetColor(150, 150, 255);
			DrawBox(0, 0, Width, Height, color, true);
			DrawGraph(1, 1, MainImage, true);	
			int y = 13;
			for (auto h = horse.begin(); h != horse.end(); h++, y += 52) {
				INFOMATION info = (INFOMATION)((nowinfo + 1) % 3);
				for (int ix = 648; ix < 849; ix += 200) {
					DisplayInfo(info, ix, y, h);
					info = (INFOMATION)((info + 1) % 3);
				}
			}
			if (!checking) {
				DrawGraph(1261, 27, StartImage, true);
				DrawGraph(1053, 732, ConfigImage, true);
			}
		}
		else {
			int r, g, b;
			SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
			switch (nowmenu->form) {
			case FORM::win:
			case FORM::top3:
				r = 200;
				g = 0;
				b = 0;
				break;
			case FORM::conbi:
				r = 200;
				g = 200;
				b = 0;
				break;
			case FORM::seq_conbi:
				r = 0;
				g = 200;
				b = 0;
				break;
			case FORM::wide:
				r = 0;
				g = 200;
				b = 200;
				break;
			case FORM::triple:
				r = 0;
				g = 50;
				b = 100;
				break;
			case FORM::seq_triple:
				r = 200;
				g = 25;
				b = 100;
				break;
			}			
			color = GetColor(r, g, b);
			DrawBox(0, 0, Width, Height,color , true);			
			SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 150);			
			DrawGraph(1, 1, MainImage, true);			
			DrawBox(650, 1, 1051, 835, GetColor(0, 0, 0), true);
			SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
			DrawBox(650, 1, 1051, 835, color, true);
			SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
			DrawGraph(1261, 27, StartImage, true);
			SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 150);
			if (nowmenu->form != FORM::win) {
				if (nowmenu->GetNowMenu() == SUB::none) {
					DrawGraph(1065, 535, FBFImage, true);
				}
				else {
					DrawGraph(1009, 6, SubImage, true);
				}
			}			
		}
		if (!checking) {
			if (nowrace.horsecount < 16) {
				if (nowmenu == betmenu.end()) {
					DrawBox(1, 835 - 52 * (16 - nowrace.horsecount), 1052, 835, color, true);
				}
				else {
					DrawBox(1, 835 - 52 * (16 - nowrace.horsecount), 1052, 835, GetColor(0, 0, 0), true);
					SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
					DrawBox(1, 835 - 52 * (16 - nowrace.horsecount), 1052, 835, color, true);
					SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 150);
				}
			}
			int y = 13;
			int hn = 1;
			if ((nowmenu == betmenu.end() && select != 0) || (nowmenu != betmenu.end() && nowmenu->GetNowMenu() == none)) {
				SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
				DrawBox(1, 1 + (select - 1) * 52, 651, 2 + select * 52, GetColor(125, 225, 25), true);
				if (nowmenu != betmenu.end() && nowmenu->form >= FORM::triple) {
					int select2 = nowmenu->GetSelect2();
					if (select2 > 0) {
						DrawBox(1, 1 + (select2 - 1) * 52, 651, 2 + select2 * 52, GetColor(175, 200, 75), true);
					}
				}
				SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 150);
			}
			for (auto h = horse.begin(); h != horse.end(); h++, y += 52, hn++) {
				DrawBox(1, y - 10, 79, y + 41, h->backcolor, true);
				if (hn > 9) {
					DrawStringToHandle(25, y, to_string(hn).c_str(), h->fontcolor, font.horseinfo);
				}
				else {
					DrawStringToHandle(35, y, to_string(hn).c_str(), h->fontcolor, font.horseinfo);
				}
				DrawStringToHandle(90, y, h->name.c_str(), GetColor(0, 0, 0), font.horseinfo);
				DisplayInfo(nowinfo, 448, y, h);
			}
			if (nowmenu != betmenu.end()) {
				SUB m = nowmenu->GetNowMenu();
				switch (m) {
				case SUB::flow:
					for (int y = 1; y < 1 + nowrace.horsecount * 52; y += 52) {
						if (nowmenu->FlowLimit() && !nowmenu->FlowLimit(653, y)) {
							SetDrawBlendMode(DX_BLENDMODE_ALPHA, 100);
						}
						DrawExtendGraph(653, y, 798, y + 50, SubButton, true);
						if (nowmenu->FlowLimitR()) {
							SetDrawBlendMode(DX_BLENDMODE_ALPHA, 100);
						}
						else {
							SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
						}
						DrawExtendGraph(802, y, 947, y + 50, SubButton, true);
						SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
					}
					break;
				case SUB::box:
					for (int y = 1; y < 1 + nowrace.horsecount * 52; y += 52) {
						if (nowmenu->BoxLimit()) {
							SetDrawBlendMode(DX_BLENDMODE_ALPHA, 100);
						}
						DrawExtendGraph(703, y, 898, y + 50, SubButton, true);
						SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 0);
					}
					break;
				case SUB::formation:
					if (nowmenu->form < FORM::triple) {
						for (int y = 1; y < 1 + nowrace.horsecount * 52; y += 52) {
							DrawExtendGraph(703, y, 778, y + 50, SubButton, true);
							DrawExtendGraph(822, y, 898, y + 50, SubButton, true);
						}
					}
					else {
						for (int y = 1; y < 1 + nowrace.horsecount * 52; y += 52) {
							DrawExtendGraph(653, y, 728, y + 50, SubButton, true);
							DrawExtendGraph(762, y, 838, y + 50, SubButton, true);
							DrawExtendGraph(872, y, 947, y + 50, SubButton, true);
						}
					}

					break;
				}
				if (m > SUB::none) {
					if (oddsnum) {
						DrawGraph(961, 521, SubOdds, true);
					}
					else {
						DrawGraph(961, 521, SubNum, true);
					}
				}
				const int* bback = (nowmenu->form > FORM::seq_conbi) ? &sbakenback : &bakenback;
				nowmenu->DisplayBaken(horse, SubSelect, *Player.chip, font.baken, *bback);
			}
			else {
				DrawGraph(1265, 741, End, true);				
			}
		}
		else {
			DisplayBetList(color);
		}
		DisplayScore();
	}
	//CREDIT,BET,WIN��\��
	void DisplayScore() {
		string score = to_string(Player.cash - ((nowmode == MODE::result) ? 0 :Player.totalbet));
		int fsize = GetFontSizeToHandle(font.odds);
		int x = 1345 - score.size() / 2 * fsize;
		x -= (score.size() > 2 && score.size() % 2 == 1) ? fsize / 4 : 0;
		DrawStringToHandle(x, 259, score.c_str(), GetColor(255, 255, 255), font.odds, GetColor(0, 0, 0));
		score = to_string(Player.totalbet);
		x = 1345 - score.size() / 2 * fsize;
		x -= (score.size() > 2 && score.size() % 2 == 1) ? fsize / 4 : 0;
		DrawStringToHandle(x, 362, score.c_str(), GetColor(255, 255, 255), font.odds, GetColor(0, 0, 0));
		score = to_string(Player.win);
		x = 1345 - score.size() / 2 * fsize;
		x -= (score.size() > 2 && score.size() % 2 == 1) ? fsize / 4 : 0;
		int wincolor = GetColor(255, 255, 255);
		/*
		result��ʂɂĔz�������������ꍇ�͕����F�����F�œ_�ł�����B�������z�������������ꍇ�͔��F�̂܂܁B
		�܂����̑��̉�ʂł����̂܂܂Ƃ���B
		*/
		DrawStringToHandle(x, 465, score.c_str(), wincolor, font.odds, GetColor(0, 0, 0));
		score = to_string(*Player.chip);
		fsize = GetFontSizeToHandle(font.odds) / 2;
		x = 1345 - score.size() / 2 * fsize;
		x -= (score.size() > 2 && score.size() % 2 == 1) ? fsize / 4 : 0;
		DrawStringToHandle(x, 568, score.c_str(), GetColor(255, 255, 255), font.odds, GetColor(0, 0, 0));
	}
	//�n����\��
	void DisplayInfo(INFOMATION info, const int& x, const int &hy, const vector<HORSE>::iterator& h) {
		int color;
		switch (info) {
		case INFOMATION::rank:
		{
			if (h->win < 10.0) {
				color = GetColor(200, 50, 75);
			}
			else {
				if (h->win > 99.9 && select != (hy - 1) / 52 + 1) {
					if (h->win > 999.9) {
						color = GetColor(250, 100, 250);
					}
					else {
						color = GetColor(225, 225, 5);
					}
				}
				else {
					color = GetColor(50, 50, 50);
				}
			}
			int d = (h->win < 10.000000000) ? 2 : (h->win < 100) ? 1 : 0;
			DrawFormatStringToHandle(x + 10 + d * 14, hy + 2, color, font.horseinfo, "%.1f", h->win);
			DrawBox(x + 147, hy - 5, x + 189, hy + 35, GetColor(0, 0, 255), true);
			DrawStringToHandle(x + 152 + ((h->rank < 10) ? 7 : 0), hy, to_string(h->rank).c_str(), GetColor(255, 255, 255), font.horseinfo);
		}
		break;
		case INFOMATION::condi:
		{
			int cx = x + 152;
			int color = 0;
			int kakudo = 0;
			switch (h->mind) {
			case MIND::best:
				color = GetColor(255, 0, 0);
				kakudo = 270;
				break;
			case MIND::good:
				color = GetColor(200, 200, 0);
				kakudo = 315;
				break;
			case MIND::ok:
				color = GetColor(0, 255, 50);
				break;
			case MIND::notok:
				color = GetColor(0, 0, 255);
				kakudo = 45;
				break;
			case MIND::bad:
				color = GetColor(150, 0, 255);
				kakudo = 90;
				break;
			}
			DrawBox(cx, hy - 7, cx + 43, hy + 38, color, true);
			DrawRotaGraph(cx + 22, hy + 15, 1.0, kakudo * PI / 180, Condition, true);
			for (int sx = x + 2; sx < x + 142; sx += 35) {
				SetDrawBright(10, 10, 10);
				switch (h->style) {
				case STYLE::runaway:
					if (sx == x + 2) SetDrawBright(100, 200, 250);
					break;
				case STYLE::normal:
					if (sx == x + 37) SetDrawBright(100, 250, 100);
					break;
				case STYLE::catchup:
					if (sx == x + 72) SetDrawBright(250, 200, 100);
					break;
				case STYLE::runafter:
					if (sx == x + 107) SetDrawBright(250, 100, 100);
					break;
				}
				DrawGraph(sx, hy + 2, Style, true);
			}
			SetDrawBright(255, 255, 255);
		}
		break;
		case INFOMATION::record:
		{
			DrawGraph(x, hy - 12, RecordImg, true);
			int rx = x + 6;
			int rhy = hy - 6;
			int backcolor, fontcolor;
			string rate;
			for (int rec = 0; rec < 5; rec++, rx += 40) {
				int xx;
				switch (h->recordrate[rec]) {
				case RATE::WBC:
					rate = "�v";
					xx = 3;
					backcolor = GetColor(150, 150, 150);
					fontcolor = GetColor(0, 0, 0);
					break;
				case RATE::G1:
					rate = "I";
					xx = 6;
					backcolor = GetColor(250, 50, 50);
					fontcolor = GetColor(255, 255, 255);
					break;
				case RATE::G2:
					rate = "II";
					xx = 3;
					backcolor = GetColor(20, 240, 0);
					fontcolor = GetColor(255, 255, 255);
					break;
				case RATE::G3:
					rate = "III";
					xx = -2;
					backcolor = GetColor(0, 250, 150);
					fontcolor = GetColor(255, 255, 255);
					break;
				}
				DrawBox(rx, rhy, rx + 28, rhy + 21, backcolor, true);
				DrawStringToHandle(rx + 4 + xx, rhy + 2, rate.c_str(), fontcolor, font.record);
				switch (h->record[rec]) {
				case 1:
					xx = 6;
					fontcolor = GetColor(200, 200, 0);
					break;
				case 2:
					xx = 6;
					fontcolor = GetColor(150, 150, 150);
					break;
				case 3:
					xx = 6;
					fontcolor = GetColor(225, 100, 25);
					break;
				default:
					fontcolor = GetColor(0, 0, 0);
					if (h->record[rec] > 9) {
						xx = 0;
					}
					else {
						xx = 6;
					}
					break;
				}

				DrawString(rx + 4 + xx, rhy + 25, to_string(h->record[rec]).c_str(), fontcolor,
					(h->record[rec] < 4) ? fontcolor : GetColor(0, 0, 0));
			}
		}
		break;
		}
	}
	//BET�ꗗ��\��
	void DisplayBetList(int color) {		
		if (nowmenu != betmenu.end()) {
			DrawBox(1, 1, 1256, 834, GetColor(0, 0, 0), true);
			SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
		}
		else {
			color = GetColor(20, 20, 20);
		}
		DrawBox(1, 1, 1256, 835, color, true);
		SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 150);
		DrawGraph(1264, 685, Back, true);		
		//BET�����S�Ă̔n������ނ��Ƃɕ\��
		int fontsize = GetFontSizeToHandle(font.horseinfo);
		string lavel[7] = { "�P��","����", "�n�A", "�n�P", "���C�h", "�O�A��", "�O�A�P" };
		if (listlimit.size() > 0) {			
			if (winwide) {
				//�P���`���C�h�܂ł�BET�ꗗ��\��
				DrawRectGraph(6, 24, 1, 1, 1240, 810, CheckSheet, true);
				int x, y;
				unsigned int bl;
				int f = 0;
				for (auto ll = listlimit.begin(); ll < listlimit.begin() + 5;ll++, f++) {					
					DrawStringToHandle((f < 4) ? 75 + 210 * f : 1005 - fontsize / 2 * 3, 28 - fontsize / 2, lavel[f].c_str(), GetColor(255, 255, 255), font.horseinfo);
					if (*ll > -1) {							
						x = 10 + 211 * f;	
						if ((FORM)(f) == FORM::wide) {
							x += 10;
						}
						bl = *ll;
						y = 108;
						auto exp = blist[f][bl];
						int count = 1;
						int bx;
						int totalbet;						
						int betcolor = GetColor(0, 255, 0);						
						if (*ll == 0) {
							SetDrawBlendMode(DX_BLENDMODE_ALPHA, 100);
						}						
						DrawGraph((f < 4) ? 85 + 210 * f : 1000, 52, ListUp, true);
						SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 150);
						unsigned int displaylimit = (unsigned int)((f < 4) ? 13 : 11);
						if (blist[f].size() - (unsigned int)(*ll) == displaylimit || blist[f].size() <= displaylimit) {								
							SetDrawBlendMode(DX_BLENDMODE_ALPHA, 100);
						}
						DrawRotaGraph2((f < 4) ? 110 + 210 * f : 1025, (f < 4) ? 790 : 700, 25, 25, 1.0, PI, ListUp, true);
						SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 150);
						fontsize = GetFontSizeToHandle(font.baken);						
						for (; bl < blist[f].size(); bl++, y += 50, count++) {
							exp = blist[f][bl];
							DrawGraph(x, y, (f  == 4) ? sbimg:bimg, true);
							DrawGraph(x, y, *exp->GetBakenGraph(), true);
							bx = x + ((FORM(f) >= FORM::wide) ? 262 : 157);
							exp->GetData(totalbet);
							DrawStringToHandle(bx + ((totalbet >= 10) ? 0 : fontsize / 2), y + mhei, to_string(totalbet).c_str(), betcolor, font.baken);
							if (exp == blist[f].back() || count == 13) {
								break;
							}
							if (FORM(f) == FORM::wide) {
								if (count == 11) {
									break;
								}
							}
						}							
					}
				}
			}
			else {
				//�O�A���E�O�A�P��BET�ꗗ��\��
				DrawRectGraph(6, 24, 1241, 1, 2101 - 1251, 810, CheckSheet, true);
				int x, y;					
				unsigned int bl;
				int f = (int)(FORM::triple);
				for (auto ll = listlimit.begin() + 5; ll != listlimit.end(); ll++, f++) {
					DrawStringToHandle((f < 6) ? 135:485, 28 - fontsize / 2, lavel[f].c_str(), GetColor(255, 255, 255), font.horseinfo);
					if (*ll > -1) {
						x = 25 + 350 * (f - 5);							
						bl = *ll;
						y = 108;
						auto exp = blist[f][bl];
						int count = 1;
						int bx;
						int totalbet;
						int fontsize = GetFontSizeToHandle(font.baken);
						int betcolor = GetColor(0, 255, 0);
						if (*ll == 0 ) {
							SetDrawBlendMode(DX_BLENDMODE_ALPHA, 100);
						}
						DrawGraph((f < 6) ? 155 : 510, 52, ListUp, true);
						SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 150);
						if (blist[f].size() - (unsigned int)(*ll) == (unsigned int)((f < 6) ? 11 : 13)) {
							SetDrawBlendMode(DX_BLENDMODE_ALPHA, 100);
						}
						DrawRotaGraph2((f < 6) ? 180 : 535, (f < 6) ? 700 : 790, 25, 25, 1.0, PI, ListUp, true);
						SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 150);
						for (; bl < blist[f].size(); bl++, y += 50, count++) {
							exp = blist[f][bl];
							DrawGraph(x, y, sbimg, true);
							DrawGraph(x, y, *exp->GetBakenGraph(), true);
							bx = x + ((FORM(f) >= FORM::wide) ? 262 : 157);
							exp->GetData(totalbet);
							DrawStringToHandle(bx + ((totalbet >= 10) ? 0 : fontsize / 2), y + mhei, to_string(totalbet).c_str(), betcolor, font.baken);
							if (exp == blist[f].back() || count == 13) {
								break;
							}
							if (FORM(f) == FORM::triple) {
								if (count == 11) {
									break;
								}
							}
						}							
					}
				}
			}
		}
		else {
			DrawRectGraph(6, 24, 1, 1, 1240, 810, CheckSheet, true);
			int x = 0;
			int y = 28 - fontsize / 2;
			for (int f = 0; f < 7; f++) {
				if (f < 4) {
					x = 75 + 210 * f;
				}
				else {
					switch (f) {
					case 4:
						x = 1005 - fontsize / 2 * 3;
						break;
					case 5:
					case 6:
						x = 25 + 350 * (f - 5);
						break;
					}
				}
				DrawStringToHandle(x, y, lavel[f].c_str(), GetColor(255, 255, 255), font.horseinfo);
			}
		}		
	}
	//�n����ύX����B�܂��z�[�����j���[���ɂ�3�̔n���̂����ꂩ��ύX����B
	void ChangeInfo() {
		nowinfo = (INFOMATION)((nowinfo + 1) % 3);
	}
	//���n�̑I�������j���[�ɔ��f����B�����Ɏ��n�𒆐S�Ƃ����n����\����Ԃɂ���B
	void SetMainHorse(int x,int y) {
		int s = (y - 1) / 52 + 1;//1�`52 �� 1 ,53�`104 �� 2
		
		if (nowmenu != betmenu.end()){
			if (nowmenu->form >= FORM::triple) {
				int select2 = nowmenu->GetSelect2();
				if (select > 0) {
					if (select == s) {
						select = select2;
						select2 = 0;
					}
					else {
						//select != s
						if (select2 == s) {
							select2 = 0;
						}
						else {
							select2 = s;
						}
					}
				}
				else {
					select = s;
				}
				nowmenu->SetMainHorse(select, select2);
			}
			else {
				//�P���E�����`���C�h�ł͎��n���ēx�I������Ă��I���������s��Ȃ�
				select = s;
				nowmenu->SetMainHorse(select);
			}
		}
		else {
			select = s;
		}
	}
	//�^�b�`���ꂽ�ꏊ�ɉ����ď������s���B
	bool touch() {		
			//flow ,box,forma,start,bet1,bet2��FBFbaken,up,down,FBFAllbet,FBFcancel�̓T�u���j���[���J���Ă��邩�ۂ��ŋ�ʂ���B
		Mouse.corsor = (BNAME)(-1);
		switch (nowmode) {
			case bet:
			{				
				auto b = button.begin();
				for (; b != button.end(); ) {
					//���j���[�o�[�A���ɖ߂�{�^���ABET���[�g�{�^���ABET�ꗗ�{�^���͂ǂ̉�ʂ̂ǂ̏�Ԃ���ł��I���\
					if (b->range(Mouse.x, Mouse.y)) {
						Mouse.corsor = b->name;
						switch (b->name) {							
						case BNAME::menubar:
						{							
							auto premenu = nowmenu;
							if (Mouse.x < 231) {
								nowmenu = betmenu.end();
								if (checking) {
									checking = false;
									CheckBaken();
								}
							}
							else {
								auto f = betmenu.begin();
								int n = (int)((Mouse.x - 230) / 170);
								if (n > 0) {
									n++;
								}
								auto next = FORM(n);
								for (; f->form != next && f != betmenu.end(); f++) {}
								nowmenu = f;
							}
							if (premenu != betmenu.end()) {
								premenu->SetFBFDisplay(false);
								if (premenu->form > FORM::wide) {
									if (nowmenu != betmenu.end() && nowmenu->form < FORM::triple) {
										premenu->SetSelect(select, 0);
									}
								}
								if (nowmenu != betmenu.end()) {
									nowmenu->SetNowMenu(premenu->GetNowMenu());
								}
							}
							if (nowmenu != betmenu.end()) {
								nowmenu->SetSelect(select, 0);
							}
							if (nowmenu != betmenu.end() && nowmenu->form == FORM::win) {
								nowmenu->SetWinOdds();
							}
							b = button.end();
						}
						break;
						case BNAME::betrate:						
							if (Player.chip == BetRate.end() - 1) {
								Player.chip = BetRate.begin();
							}
							else {
								Player.chip++;
							}
							b = button.end();						
							break;
						case BNAME::Undo:						
							ProcessUndo();
							b = button.end();
							break;
						case BNAME::betlist:						
							checking = !checking;
							CheckBaken();
							b = button.end();
							break;
						default:
							if (checking) {		
								Mouse.corsor = BNAME::betlist;
								int bl = 0;
								bool bflg = false;
								for (; bl < 14;bl++) {
									if (betlistbutton[bl].range(Mouse.x, Mouse.y)) {									
										if (winwide) {										
											//win~wide
											switch (bl) {
											case 0://win
											case 1://top3_up
											case 2://conbi_up
											case 3://seq_conbi_up
											case 4://wide_up
												if (listlimit[bl] > 0) {
													listlimit[bl]--;
												}
												else {
													Mouse.corsor = (BNAME)(-1);
												}
												break;
											case 7://win_down
											case 8://top3_down
											case 9://conbi_down
											case 10://seq_conbi_down
												if (blist[bl - 7].size() - listlimit[bl - 7] > 13) {
													listlimit[bl - 7]++;
												}
												else {
													Mouse.corsor = (BNAME)(-1);
												}
												break;
											case 11://wide_down
												if (blist[bl - 7].size() - listlimit[bl - 7] > 11) {
													listlimit[bl - 7]++;
												}
												else {
													Mouse.corsor = (BNAME)(-1);
												}
												break;
											}	
											break;
										}
										else {										
											switch (bl) {
											case 5://triple_up
											case 6://seq_triple_up
												if (listlimit[bl] > 0) {
													listlimit[bl]--;
												}
												else {
													Mouse.corsor = (BNAME)(-1);
												}
												bflg = true;
												break;
											case 12://seq_triple_down
												if (blist[bl - 7].size() - listlimit[bl - 7] > 11) {
													listlimit[bl - 7]++;
												}
												else {
													Mouse.corsor = (BNAME)(-1);
												}
												bflg = true;
												break;
											case 13://seq_triple_down
												if (blist[bl - 7].size() - listlimit[bl - 7] > 13) {
													listlimit[bl - 7]++;
												}
												else {
													Mouse.corsor = (BNAME)(-1);
												}
												bflg = true;
												break;
											}										
										}
										if (bflg) {
											break;
										}
									}
								}
								if (betlistbutton[14].range(Mouse.x, Mouse.y) && winwide) {
									winwide = false;
								}
								if (betlistbutton[15].range(Mouse.x, Mouse.y) && !winwide) {
									winwide = true;
								}
								/*if (bl == 14 && b->name < BNAME::bflow) {
									b++;
								}
								else {
									b = button.end();
								}*/
								b = button.end();
							}
							else {
								if (nowmenu == betmenu.end()) {
									//bet1,bet2�����ꂼ��info2,info3�ƂȂ�AFBF�n���͖�������B
									if (b->name < start) {
										if (Mouse.x < 1050 && Mouse.y < 832 - (16 - nowrace.horsecount) * 52) {
											Mouse.corsor = b->name;
											switch (b->name) {
											case BNAME::horse:
												//�厲�n��I��
												SetMainHorse(Mouse.x, Mouse.y);
												break;
											case info:
											case bet1://�z�[�����j���[�̏ꍇ��info2										
											case bet2://�z�[�����j���[�̏ꍇ��info3
												//���X�V
												//ChangeInfo(BNAME b);
												Mouse.corsor = (BNAME)(-1);
												break;
											}
											b = button.end();
										}
										else {
											b++;
										}
									}
									else {
										if (b->name < bflow) {
											switch (b->name) {
											case start:
												//���[�X�J�n
												nowmode = race;
												//for (int m = 1; m < 4; m++) {
													//if (CheckSoundMem(*Music[m])) {
														StopSoundMem(Music);
												//	}
												//}
												break;
											case Undo:
												//1��߂�
												ProcessUndo();
												break;
											case Option:
												//�I�v�V������ʂ��J��
												nowmode = config;
												resetcheck = false;
												Mouse.corsor = BNAME::menubar;
												DisplayMenu();
												GetDrawScreenGraph(1, 1, 1450, 910, configback);//�w�i�Ƃ��ĕۑ�
												break;
											case BNAME::End:
												//�Q�[���I��
												nowmode = io;
												break;
											}
											b = button.end();										
										}
										else {
											Mouse.corsor = (BNAME)(-1);
											b++;
										}
									}
								}
								else {
									if (nowmenu->GetNowMenu() == 0) {
										//�ʏ��� FBF�n���͖���
										if (b->name < BNAME::End) {
											if (Mouse.x < 1060 && Mouse.y < 832 - (16 - nowrace.horsecount) * 52) {
												switch (b->name) {
												case BNAME::horse:
													//�厲�n��I��
													SetMainHorse(Mouse.x, Mouse.y);
													break;
												case info:
													//���X�V
													Mouse.corsor = b->name;
													ChangeInfo();
													break;
												case bet1:
												case bet2:
													//�Ώ۔n����BET
												{
													if (Player.cash - *Player.chip > -1) {
														vector<baken*> bak;
														nowmenu->bet(Mouse.x, Mouse.y, *Player.chip, bak);
														if (bak.size() > 0) {
															int step = (played.size() == 0) ? 1 : played.back().step + 1;
															if (bak.size() == 1) {
																played.emplace_back(nowmenu->form, bak[0], *Player.chip, step);
																Player.totalbet += *Player.chip;
															}
															else {
																for (auto pb = bak.begin(); pb != bak.end(); pb++) {
																	played.emplace_back(nowmenu->form, *pb, *Player.chip, step);
																	Player.totalbet += *Player.chip;
																}
																Mouse.corsor = FBFallbet;//��BET��ɂ���ALLBET���^�b�`���ꂽ�Ƃ���FBFALLbet�Ɠ�������炷�B
															}
														}
														else {
															Mouse.corsor = (BNAME)(-1);
														}
													}
													else {
														Mouse.corsor =  (BNAME)(-1);
													}
												}
												break;
												default:
													Mouse.corsor = (BNAME)(-1);
													break;
												}
												b = button.end();
											}
											else {
												b++;
												Mouse.corsor = (BNAME)(-1);
											}
										}
										else {
											if (b->name < FBFplot) {											
												switch (b->name) {
													//�z�[�����j���[�ȊO�̃��j���[�ɂ�����I���{�^����Formation�{�^���Ɠ���
												case bflow:
												case bbox:
												case bforma:
													if (nowmenu->form != FORM::win) {
														oddsnum = false;
														nowmenu->SetFBFDisplay(oddsnum);
														nowmenu->SetNowMenu(SUB(b->name - (int)(BNAME::End)));
													}
													break;
												}
												Mouse.corsor = b->name;
												b = button.end();											
											}
											else {
												b++;
											}
										}
									}
									else {
										//�T�u���j���[ bet1,bet2�͖���
										if (b->name >= FBFplot) {										
											Mouse.corsor = b->name;
											switch (b->name) {
											case FBFplot:
												//�^�b�`���ꂽ�ꏊ�����ɔn��I������B
												if (Mouse.y < 832 - (16 - nowrace.horsecount) * 52) {
													if (!nowmenu->SetSubSelect(Mouse.x, Mouse.y)) {
														Mouse.corsor = (BNAME)(-1);
													}
												}
												break;
											case FBFbaken:
											{
												if (Player.cash - *Player.chip > -1) {
													vector<baken*> bak;
													nowmenu->bet(Mouse.x, Mouse.y, *Player.chip, bak);
													if (bak.size() == 1) {
														int step = (played.size() == 0) ? 1 : played.back().step + 1;
														played.emplace_back(nowmenu->form, bak[0], *Player.chip, step);
														Player.totalbet += *Player.chip;
													}
													else {
														Mouse.corsor =  (BNAME)(-1);
													}
												}
												else {
													Mouse.corsor =  (BNAME)(-1);
												}
											}
											break;
											case up:
												nowmenu->FBFSelect(true);
												break;
											case down:
												nowmenu->FBFSelect(false);
												break;
											case FBFallbet:
											{
												vector<baken*> checking;
												checking.clear();
												nowmenu->FBFAllBet(Player.cash,*Player.chip, checking);
												if (checking.size() != 0) {
													int step = (played.size() == 0) ? 1 : played.back().step + 1;
													for (auto b = checking.begin(); b != checking.end(); b++) {
														played.emplace_back(nowmenu->form, *b, *Player.chip, step);
														Player.totalbet += *Player.chip;
													}
												}
												else {
													Mouse.corsor =  (BNAME)(-1);
												}
											}
											break;
											case FBFoddsnum:
												oddsnum = !oddsnum;
												nowmenu->SetFBFDisplay(oddsnum);
												break;
											case FBFcancel:
												nowmenu->SetNowMenu(none);
												break;
											}
											b = button.end();
										
										}
										else {
											if (b->name == Undo && b->range(Mouse.x, Mouse.y)) {
												ProcessUndo();
												b = button.end();
											}
											else {
												b++;
											}
										}
									}
								}
							}
							break;
						}
					}
					else {
						b++;
					}
					
				}
				if (Mouse.corsor != (BNAME)(-1)) {
					return true;
				}
			}
				
				break;
			case config:
			{
				if (resetcheck) {
					//�������m�F���
					int rx = 400;
					int ry = 350;
					if (Mouse.y > ry + 220 && Mouse.y < ry + 253) {
						if (Mouse.x > rx + 44 && Mouse.x < rx + 146) {
							//�I�v�V������ʂɖ߂�
							resetcheck = false;
							Mouse.corsor = BNAME::Undo;
						}
						if (Mouse.x > rx + 284 && Mouse.x < rx + 354) {
							//�S�f�[�^������
							DrawBox(1, 1, 1450, 910,GetColor(0,0,0),true);
							nowmode = MODE::bet;
							Player.cash = 1000;							
							Player.chip = BetRate.begin();
							Player.maxconbo = 1;
							Player.maxwin = 100;
							NewGame();
							Mouse.corsor = BNAME::menubar;
						}
					}
				}
				else {
					vector<string>setting = {
					"BGM ����",
					"SE ����",
					"�S�f�[�^������",
					"�Q�[���ɖ߂�"
					};
					auto lavel = setting.begin();
					int sz = GetFontSizeToHandle(font.horseinfo);
					for (int y = 377; y < 792; y += 104) {
						if (Mouse.x > 520 && Mouse.x < 520 + (int)(lavel->size() * sz) && Mouse.y > y && Mouse.y < y + sz) {
							
							switch (y) {
							case 377:
								Mouse.corsor = BNAME::bet1;
								Player.BGMVolume++;
								Player.BGMVolume %= 11;
								break;
							case 481:
								Mouse.corsor = BNAME::bet1;
								Player.SEVolume++;
								Player.SEVolume %= 11;
								break;
							case 585:
								Mouse.corsor = BNAME::betlist;
								resetcheck = true;
								y = 800;
								break;
							case 689:
								Mouse.corsor = BNAME::Undo;
								nowmode = bet;
								y = 800;
								break;
							}
						}
					}
					if (Mouse.x < 500 || Mouse.x > 1250 || button[0].range(Mouse.x, Mouse.y)) {
						nowmode = bet;
					}
					if (nowmode == bet) {
						for (int s = SOUND::SEselect; s < SEwin + 1; s++) {
							ChangeVolumeSoundMem((Player.SEVolume == 10) ? 255 : Player.SEVolume * 26, Sound[s]);
						}
						//for (int m = 0; m < 4; m++) {
							ChangeVolumeSoundMem((Player.BGMVolume == 10) ? 255 : Player.BGMVolume * 26, Music);
						//}
					}
				}
			}
				break;
			case race:
				SetResult();
				nowmode = MODE::result;				
				ChangeMusic();
				if (Player.win > 0) {
					PlaySoundMem(Sound[SEwin], DX_PLAYTYPE_NORMAL, true);
				}
				break;
			case result:
				nowmode = MODE::bet;
				StopSoundMem(Music);
				NewGame();
				while (horse[0].rank < 0) {//�o�O���
					NewGame();
				}				
				ChangeMusic();
				break;
			}
			return (Mouse.corsor != (BNAME)(-1)) ? true : false;
	}
	//�^�b�`���܂��̓h���b�O���̏������s���B�e��{�^���ɊY�����Ă���ꍇ�̓{�^���̑傫���ɍ��킹�ē_��������B
	void touching() {
		for (auto b = button.begin(); b != button.end();b++) {
			if (b->range(Mouse.x, Mouse.y)) {
				int x, y, x2, y2, x3, y3;
				b->GetbotanRange(x, y, x2, y2, x3, y3);	
				touchbuttonfix(b->name, x, y, x2, y2);
				if (x3 == 0 && y3 == 0) {
					if (y2 == 0) {
						//�~
						SetDrawBlendMode(DX_BLENDMODE_ALPHA, 100);
						DrawCircle(x, y, x2 - 3, GetColor(255, 255, 0), true, 3);
					}
					else {
						//�l�p�`
						
						if (x != 0 && y != 0) {
							if (!((b->name == BNAME::bet1 || b->name == BNAME::bet2) && checking) && !(nowmenu != betmenu.end() && b->name == BNAME::Option)) {
								if (b->name == BNAME::FBFplot) {
									SetDrawBlendMode(DX_BLENDMODE_INVSRC, 150);
								}
								else {
									SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
								}
								SetDrawBright(200, 200, 0);
								DrawExtendGraph(x + 2, y + 2, x2 - 2, y2 - 2, bshadow, true);
								SetDrawBright(255, 255, 255);
							}
						}
					}
				}
				else {
					//�O�p�`
					if (x != 0 && y != 0) {
						if (b->name == BNAME::down) {
							x += 3;
							y += 3;
							x2 = 1180;
							y3 -= 3;
						}
						else {
							x2 = 1180;
							y3 += 8;
							y += 3;
						}
						SetDrawBlendMode(DX_BLENDMODE_ALPHA, 100);
						DrawTriangle(x, y, x2, y, x3, y3, GetColor(255, 255, 0), true);
					}
				}
				SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 100);
			}
		}
		if (checking) {
			int bn = 0;			
			for (auto b = betlistbutton.begin(); b != betlistbutton.end(); b++,bn++) {
				bool able = true;
				switch (bn + ((winwide) ? 0 : 100)) {
				case 100:
				case 101:
				case 102:
				case 103:
				case 104:
				case 5:
				case 6:
				case 107:
				case 108:
				case 109:
				case 110:
				case 111:
				case 12:
				case 13:
				case 114:
				case 15:
					able = false;
					break;
				}
				if (able && b->range(Mouse.x, Mouse.y)) {
					int x1, x2, y1, y2;
					b->GetbotanRange(x1, y1, x2, y2);
					if (y2 == 0) {
						//�~�`
						if (bn < 7) {
							if (listlimit[bn] == 0 || blist[bn].size() == 0) {
								able = false;
							}
						}
						else {
							int limit = 13;
							if (bn == 11 || bn == 12) {
								limit = 11;
							}
							if (blist[bn - 7].size() - listlimit[bn - 7] < (unsigned int)(limit)) {
								able = false;
							}							
						}
						if (able) {
							SetDrawBlendMode(DX_BLENDMODE_ALPHA, 100);
							DrawCircle(x1, y1, x2 - 3, GetColor(255, 255, 0), true);
						}
					}
					else {	
						
						if (x1 != 0 && y1 != 0) {
							SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
							SetDrawBright(150, 150, 0);
							DrawExtendGraph(x1 + 2, y1 + 2, x2 - 2, y2 - 2, bshadow, true);
							SetDrawBright(255, 255, 255);
						}
					}
					SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 100);
				}
			}
		}
	}
	//�^�b�`���ɓ_��������{�^���̕\���͈͂̒���
	void touchbuttonfix(const BNAME& b, int& x, int& y, int& x2, int& y2) {
		bool single = false;
		switch (b) {
		case BNAME::menubar:
			if (Mouse.x < 230) {
				x = 1;
				x2 = 230;
			}
			else {
				for (int bx = 231; bx < 1250; bx += 170) {
					if (bx <= Mouse.x && bx + 170 >= Mouse.x) {
						x = bx;
						x2 = bx + 170;
						break;
					}
				}
			}
			break;
		case BNAME::horse:
		case BNAME::info:
			x = 0;
			y = 0;
			break;
		case BNAME::start:
			if (nowmenu != betmenu.end()) {
				x = 0;
				y = 0;
			}
			break;
		case BNAME::End:
			y2 -= 7;
			if (nowmenu != betmenu.end()) {
				x = 0;
				y = 0;
			}
			break;
		case BNAME::betrate:
			x2 = 1440;
			y2 = 598;
			break;
		case BNAME::Undo:
		case BNAME::betlist:
			x -= 3;
			y2 += 3;
			break;
		case BNAME::bet1:
			if (nowmenu == betmenu.end()) {
				x = 0;
				y = 0;
			}
			else {
				if (nowmenu->GetNowMenu() == SUB::none) {
					single = true;
				}
				else {
					x = 0;
					y = 0;
				}
			}
			break;
		case BNAME::bet2:
			if (nowmenu == betmenu.end()) {
				x = 0;
				y = 0;
			}
			else {
				if (nowmenu->GetNowMenu() == SUB::none) {
					nowmenu->SingleRange(Mouse.x, Mouse.y, x, y);
					single = true;
				}
				else {
					x = 0;
					y = 0;
				}
			}
			break;
		case BNAME::FBFplot:
			if (nowmenu != betmenu.end()) {
				nowmenu->GetFBFRange(Mouse.x, Mouse.y, x, y, x2, y2);
			}
			else {
				x = 0;
				y = 0;
			}
			break;
		case BNAME::FBFbaken:
			if (nowmenu == betmenu.end()) {
				x = 0;
				y = 0;
			}
			else {
				if (nowmenu->GetNowMenu() > SUB::none) {
					single = true;
				}
				else {
					x = 0;
					y = 0;
				}
			}
			break;
		}
		if (checking) {
			switch (b) {
			case BNAME::menubar:
			case BNAME::Undo:
			case BNAME::betlist:
			case BNAME::betrate:
				break;
			default:
				x = 0;
				y = 0;
			}
		}
		if (single) {
			nowmenu->SingleRange(Mouse.x, Mouse.y, x, y);
			if (x != 0 && y != 0) {
				if (nowmenu->form >= FORM::wide) {
					x2 = x + 300;
				}
				else {
					x2 = x + 196;
				}
				y2 = y + 49;
			}
		}
		if (b >= FBFplot) {
			if (nowmenu == betmenu.end() || nowmenu->GetNowMenu() == SUB::none) {
				x = 0;
				y = 0;
			}
		}
		if ((b >= bet1 && b <= bet2 ) || (b >= bflow && b <= bforma)) {
			if (nowmenu == betmenu.end() || nowmenu->GetNowMenu() != SUB::none) {
				x = 0;
				y = 0;
			}
		}
	}
	//1��߂�����
	void ProcessUndo() {
		if (played.size() > 0) {
			int step = played.back().step;
			auto play = played.back();
			FORM form = play.form;
			while (played.size() > 0 && played.back().step == step) {
				//FBF��ALLBET�ɂ�蓯���菇�ڂɍs�����S�Ă�BET���L�����Z������B
				play.bak->CANCEL(play.chip);
				Player.totalbet -= play.chip;
				played.pop_back();
				if (played.size() > 0) {
					play = played.back();
					form = play.form;
				}
			}
			//�Ō�ɍs����BET�̃��j���[�ɖ߂�
			checking = false;
			auto premenu = nowmenu;
			nowmenu = betmenu.begin() + (int)(form);
			if (form != FORM::win) {
				nowmenu--;
			}
			if (premenu != betmenu.end() && premenu != nowmenu) {
				premenu->SetNowMenu(none);
				premenu->SetFBFDisplay(false);
				if (premenu->form > FORM::wide) {
					if (nowmenu != betmenu.end() && nowmenu->form < FORM::triple) {
						premenu->SetSelect(select, 0);
					}
				}
			}			
			vector<int>lavel;
			play.bak->GetData(lavel);
			//���j���[�ύX���̏���
			switch (form) {
			case FORM::win:
				nowmenu->SetWinOdds();
				break;
			case FORM::conbi:
			case FORM::seq_conbi:
			case FORM::wide:				
				if (premenu == nowmenu ){
					if (premenu->GetNowMenu() == 0) {
						select = lavel[0];
						nowmenu->SetMainHorse(lavel[0]);
					}
					else {
						nowmenu->FBFSort();
					}
				}
				break;
			case FORM::triple:
			case FORM::seq_triple:				
				if (premenu == nowmenu) {
					if (premenu->GetNowMenu() == 0) {
						select = lavel[0];
						nowmenu->SetMainHorse(lavel[0],lavel[1]);
					}
					else {
						nowmenu->FBFSort();
					}
				}
				break;
			}			
		}
	}
	//�I�v�V��������
	void ProcessOption() {
		SetDrawBlendMode(DX_BLENDMODE_ALPHA, 100);
		DrawGraph(1, 1, configback, true);
		SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 100);
		DrawBox(500, 1, 1250, 910, GetColor(0, 0, 0), false);
		DrawBox(501, 2, 1249, 909, GetColor(200, 200, 200), true);
		DrawBox(549, 49, 1201, 301, GetColor(0, 0, 0), false);
		DrawBox(550, 50, 1200, 300, GetColor(255, 255, 255), true);
		if (resetcheck) {
			// 44 220 146 253
			//284 220 354 253
			int rx = 400;
			int ry = 350;			
			DrawGraph(rx, ry, ResetImage, true);
			if (Mouse.y > ry + 220 && Mouse.y < ry + 253) {
				if (Mouse.x > rx + 44 && Mouse.x < rx + 146) {
					SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
					DrawBox(rx + 44, ry + 220, rx + 146, ry + 253, GetColor(0, 0, 0), true);
					SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 150);
				}
				if (Mouse.x > rx + 284 && Mouse.x < rx + 354) {
					SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
					DrawBox(rx + 284, ry + 220, rx + 354, ry + 253, GetColor(0, 0, 0), true);
					SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 150);
				}
			}
		}
		else {			
			string lav = string("�ő�l���z��     ") + to_string(Player.maxwin);
			DrawStringToHandle(570, 180, lav.c_str(), GetColor(255, 0, 0), font.horseinfo);
			lav = string("�ő�R���{��     ") + to_string(Player.maxconbo);
			DrawStringToHandle(570, 250, lav.c_str(), GetColor(0, 255, 0), font.horseinfo);
			DrawStringToHandle(900, 250, "���|�����̔{�ȏ��", GetColor(150, 150, 0), font.odds);
			DrawStringToHandle(900, 270, "�z���l��������", GetColor(150, 150, 0), font.odds);
			vector<string>setting = {
				"BGM ����",
				"SE ����",
				"�S�f�[�^������",
				"�Q�[���ɖ߂�"
			};
			DrawStringToHandle(520, 320, "�����L�̕������^�b�`���邱�Ƃő���ł��܂�", GetColor(150, 150, 0), font.baken);
			auto lavel = setting.begin();
			int sz = GetFontSizeToHandle(font.horseinfo);
			
			for (int y = 377; y < 792; y += 104) {
				switch (y) {
				case 377:
					*lavel +="  " + to_string(Player.BGMVolume);
					break;
				case 481:
					*lavel += "  " + to_string(Player.SEVolume);
					break;
				}
				int mojisu = lavel->size() / 2 + 1;
				DrawStringToHandle(520, y, lavel->c_str(), GetColor(0, 0, 0), font.horseinfo);
				if (Mouse.x > 520 && Mouse.x < 520 + (int)(mojisu * sz) && Mouse.y > y && Mouse.y < y + sz) {
					switch (Mouse.click) {
					case 0:
						DrawBox(520, y, 520 + mojisu * sz, y + sz, GetColor(0, 0, 0), false);
						break;
					case 3:
					case 4:
						SetDrawBlendMode(DX_BLENDMODE_ALPHA, 150);
						DrawBox(520, y, 520 + mojisu * sz, y + sz, GetColor(0, 0, 0), true);
						SetDrawBlendMode(DX_BLENDMODE_NOBLEND, 150);
						break;
					}
				}
				lavel++;
			}
		}
	}
	//BET�ꗗ��\�����邽�߂̏����B�ʏ��ʂɖ߂�ꍇ�͂��̌�Еt�����s���B
	void CheckBaken() {
		if (checking) {
			//BET�ꗗ��\��
			for (auto pl = played.begin(); pl != played.end(); pl++) {
				int f = 0;
				pl->bak->GetFormToInt(f);				
				if (blist[f].size() == 0) {
					blist[f].push_back(pl->bak);
				}
				else {
					if (find(blist[f].begin(), blist[f].end(), pl->bak) == blist[f].end()) {
						blist[f].push_back(pl->bak);
					}
				}
			}
			int l = 0;
			for (auto m : FORM()) {
				int f = (int)(m);
				sort(blist[f].begin(), blist[f].end());
				if (blist[f].size() > 0) {
					listlimit.push_back(0);
				}
				else {
					listlimit.push_back(-1);
				}
			}
		}
		else {
			//�ʏ��ʂɖ߂�			
			winwide = true;
			listlimit.clear();
			for (auto m : FORM()) {
				blist[(int)(m)].clear();
			}
		}
	}
	//�n���l�ɉ����ă��[�X���ʂ𒊑I�B
	void SetResult() {
		vector<double>hvalue;
		struct racing {
			racing(vector<HORSE>::iterator nb, int n) :b(nb), num(n) {

			}
			vector<HORSE>::iterator b;
			int num;			
		};
		vector<racing> hhorse;
		vector<int>lavel;
		Player.cash -= Player.totalbet;
		int num = 1;
		//�n���y�єn�ԍ���o�^
		for (auto h = horse.begin(); h != horse.end(); h++,num++) {
			h->num = num;
			hhorse.emplace_back(h,num);
		}
		double total = 0;		
		int res;
		//���[�X���ʂ𒊑I
		while (RaceResult.size() < (unsigned int)(nowrace.horsecount)) {
			if (hhorse.size() == 1) {
				RaceResult.push_back(hhorse[0].b);
			}
			else {
				total = 0;
				hvalue.clear();
				for (auto h = hhorse.begin(); h != hhorse.end(); h++) {
					auto hv = *h->b;					
					total += hv.value;
					hvalue.push_back(total);
				}
				res = GetRand((int)(total));
				auto hh = hhorse.begin();
				for (auto hv = hvalue.begin(); hv != hvalue.end(); hv++, hh++) {
					if (*hv >= res) {
						RaceResult.push_back(hh->b);
						if (lavel.size() < 3) {
							lavel.push_back(hh->num);
						}
						hhorse.erase(hh);
						break;
					}
				}
			}
		}		
		
		//�Y���n�������������o�^�B
		ReCalc rc;
		for (auto mn = betmenu.begin(); mn != betmenu.end();mn++) {
			double odds = 0;
			int bet = 0;
			switch (mn->form) {
			case FORM::win:
			{
				//�P��
				mn->GetHitBakenInfo(lavel,bet,odds);
				hitbaken.emplace_back(mn->form, odds, bet);
				Player.win += (int)(odds * bet);
				//����
				mn->GetHitBakenInfo(lavel, rc.bet, FORM::top3);
				rc.resultvalue = RaceResult[1]->value + RaceResult[2]->value;
				rc.value = RaceResult[0]->value;
				ReCalcOdds(FORM::top3, rc);
				vector<int>llavel;
				//1,2,3 �� 2,3,1
				copy(lavel.begin() + 1, lavel.end(), back_inserter(llavel));
				llavel.push_back(0);
				mn->GetHitBakenInfo(llavel, rc.bet, FORM::top3);
				rc.resultvalue = RaceResult[0]->value + RaceResult[2]->value;
				rc.value = RaceResult[1]->value;
				ReCalcOdds(FORM::top3, rc);
				//1,2,3 �� 3,2,1
				reverse_copy(lavel.begin(), lavel.end(), back_inserter(llavel));
				mn->GetHitBakenInfo(llavel, rc.bet, FORM::top3);
				rc.resultvalue = RaceResult[1]->value + RaceResult[0]->value;
				rc.value = RaceResult[2]->value;
				ReCalcOdds(FORM::top3,rc);
			}
			break;
			case FORM::wide:
			{				
				mn->GetHitBakenInfo(lavel, rc.bet);
				rc.resultvalue = nowrace.totalvalue - RaceResult[2]->value;
				rc.value = RaceResult[0]->value;
				rc.value2 = RaceResult[1]->value;
				ReCalcOdds(mn->form, rc);
				vector<int>llavel;
				//1,2,3 �� 1,3,2
				llavel.push_back(lavel[0]);
				llavel.push_back(lavel[2]);
				llavel.push_back(0);
				mn->GetHitBakenInfo(llavel, rc.bet);
				rc.resultvalue = nowrace.totalvalue - RaceResult[1]->value;
				rc.value = RaceResult[0]->value;
				rc.value2 = RaceResult[2]->value;
				ReCalcOdds(mn->form, rc);
				//1,2,3 �� 3,2,1
				reverse_copy(lavel.begin(), lavel.end(), back_inserter(llavel));
				mn->GetHitBakenInfo(llavel, rc.bet);
				rc.resultvalue = nowrace.totalvalue - RaceResult[0]->value;
				rc.value = RaceResult[2]->value;
				rc.value2 = RaceResult[1]->value;
				ReCalcOdds(mn->form, rc);				
			}
				break;
			default:
				mn->GetHitBakenInfo(lavel, bet, odds);
				if (odds != 0) {
					hitbaken.emplace_back(mn->form, odds, bet);
					Player.win += (int)(odds * bet);
				}
			}
		}
		Player.cash += Player.win;
		if (Player.win == 0 || Player.win / Player.totalbet < 2) {
			Player.conbo = 0;
		}
		else {
			Player.conbo++;
		}
		if (Player.win > Player.maxwin)Player.maxwin = Player.win;
		if (Player.conbo > Player.maxconbo)Player.maxconbo = Player.conbo;
	}
	//���[�X���ʂ̊Y���n���̂��������E���C�h�̓��[�X���ʂ����ɃI�b�Y���Čv�Z����B
	void ReCalcOdds(FORM f, ReCalc rc) {
		//auto bb = *b;
		double odds;
		switch (f) {
		case FORM::top3:
			odds = (double)(floor((nowrace.totalvalue - rc.resultvalue) / rc.value / 3 * 10) / 10);
			hitbaken.emplace_back(f, odds, rc.bet);
			Player.win += (int)(odds * rc.bet);
			break;
		case FORM::wide:
			odds = (double)(floor(rc.resultvalue / rc.value * (rc.resultvalue - rc.value) / rc.value2
				+ rc.resultvalue / rc.value2 *
				(rc.resultvalue - rc.value2) / rc.value) / nowrace.horsecount);
			odds = (double)(floor(odds * 10) / 10);
			hitbaken.emplace_back(f, odds, rc.bet);
			Player.win += (int)(odds * rc.bet);
			break;
		}
	}
	//���ʉ�ʂ�\������B
	void DisplayResult() {
		DrawBox(0, 0, Width, Height, GetColor(0, 0, 100), true);
		DrawGraph(460, 13, ResultImg, true);
		DrawRectGraph(1250, 200, 1250, 200, 195, 400, MainImage, true);
		DisplayScore();
		int y = 30;
		for (auto h = RaceResult.begin();h != RaceResult.end(); y += mhei * 4,h++) {
			auto hh = *h;
			DrawBox(25, y - 10, 70, y + 35, hh->backcolor, true);
			DrawStringToHandle(40 + ((hh->num < 10) ? 0 : -10) , y, to_string(hh->num).c_str(), hh->fontcolor, font.horseinfo);
			DrawStringToHandle(90, y, hh->name.c_str(), GetColor(255,255,255), font.horseinfo);
		}
		string formlavel[8] = { "�P��","����","�n�A","�A�P","���C�h","�O�A��","�O�A�P", "���v"};
		int formy[8] = { 32,162,292,357,487,617,682 ,773};
		auto winner = hitbaken.begin();
		for (int f = 0; f < 8; f++,winner++) {
			DrawStringToHandle(((formlavel[f].size() == 2) ? 460 : 480), formy[f], formlavel[f].c_str(), GetColor(255, 255, 255), font.horseinfo);
			switch (f) {
			case 1:
				DisplayHitBaken(f, formy[f] - 65, winner->odds, winner->bet);
				winner++;
				DisplayHitBaken(f, formy[f], winner->odds, winner->bet);
				winner++;
				DisplayHitBaken(f, formy[f] + 65, winner->odds, winner->bet);
				break;
			case 4:
				DisplayHitBaken(f, formy[f] - 65, winner->odds, winner->bet);
				winner++;
				DisplayHitBaken(f, formy[f], winner->odds, winner->bet);
				winner++;
				DisplayHitBaken(f, formy[f] + 65, winner->odds, winner->bet);
				break;
			case 7:
				DrawStringToHandle(1100, formy[f] + 4, to_string(Player.win).c_str(), GetColor(255, 255, 255), font.horseinfo);
				winner--;
				break;
			default:
				DisplayHitBaken(f, formy[f], winner->odds, winner->bet);
				break;
			}
			
		}
		if (Player.win == Player.maxwin && Player.win > 0) {
			DrawStringToHandle(600, 740, "�ō��l���z���L�^�X�V!!", GetColor(255, 0, 0), font.baken);
		}
		if (Player.conbo == Player.maxconbo && Player.conbo > 0) {
			DrawStringToHandle(600, 780, "�ő�R���{���L�^�X�V!!", GetColor( 0, 255, 0), font.baken);
		}
	}
	void DisplayHitBaken(const int f ,const int y,const double odds,const int bet) {
		DrawFormatStringToHandle(830, y , GetColor(255, 255, 255), font.horseinfo, "% 5.1f",odds);
		DrawFormatStringToHandle(970, y + 4, GetColor(0, 255, 0), font.horseinfo, " �~%d", bet);
		DrawStringToHandle(1050, y + 4,"=", GetColor(255, 255, 255), font.horseinfo);
		DrawStringToHandle(1100, y + 4, to_string((int)(odds * bet)).c_str(), GetColor(255, 255, 255), font.horseinfo);
		switch (f) {
		case 0://�P��		
		{
			auto hh = RaceResult[0];
			DrawBox(675,y - 9, 720, y + 36, hh->backcolor, true);
			DrawStringToHandle(690 + ((hh->num < 10) ? 0 : -10), y, to_string(hh->num).c_str(), hh->fontcolor, font.horseinfo);

		}
			break;
		case 1://����
		{
			auto hh = (y < 162) ? RaceResult[0] : (y > 162) ? RaceResult[2] : RaceResult[1];
			DrawBox(675, y - 9, 720, y + 36, hh->backcolor, true);
			DrawStringToHandle(690 + ((hh->num < 10) ? 0 : -10), y, to_string(hh->num).c_str(), hh->fontcolor, font.horseinfo);
		}
			break;
		case 2://�n�A
		{
			auto h1 = (RaceResult[0]->num < RaceResult[1]->num) ? RaceResult[0] : RaceResult[1];
			auto h2 = (RaceResult[0]->num < RaceResult[1]->num) ? RaceResult[1] : RaceResult[0];
			DrawStringToHandle(690, y, "-", GetColor(255, 255, 255), font.horseinfo);
			DrawBox(625, y - 9, 670, y + 36, h1->backcolor, true);
			DrawStringToHandle(640 + ((h1->num < 10) ? 0 : -10), y, to_string(h1->num).c_str(), h1->fontcolor, font.horseinfo);
			DrawBox(725, y - 9, 770, y + 36, h2->backcolor, true);
			DrawStringToHandle(740 + ((h2->num < 10) ? 0 : -10), y, to_string(h2->num).c_str(), h2->fontcolor, font.horseinfo);
		}
			break;
		case 3://�A�P
		{
			auto h1 = RaceResult[0];
			auto h2 = RaceResult[1];
			DrawStringToHandle(690, y, ">", GetColor(255, 255, 255), font.horseinfo);
			DrawBox(625, y - 9, 670, y + 36, h1->backcolor, true);
			DrawStringToHandle(640 + ((h1->num < 10) ? 0 : -10), y, to_string(h1->num).c_str(), h1->fontcolor, font.horseinfo);
			DrawBox(725, y - 9, 770, y + 36, h2->backcolor, true);
			DrawStringToHandle(740 + ((h2->num < 10) ? 0 : -10), y, to_string(h2->num).c_str(), h2->fontcolor, font.horseinfo);
		}
			break;
		case 4://���C�h
		{
			auto h1 = RaceResult[0];
			auto h2 = RaceResult[1];
			switch (y) {
			case 422:
				h1 = (RaceResult[0]->num < RaceResult[1]->num) ? RaceResult[0] : RaceResult[1];
				h2 = (RaceResult[0]->num < RaceResult[1]->num) ? RaceResult[1] : RaceResult[0];
				break;
			case 487:
				h1 = (RaceResult[0]->num < RaceResult[2]->num) ? RaceResult[0] : RaceResult[2];
				h2 = (RaceResult[0]->num < RaceResult[2]->num) ? RaceResult[2] : RaceResult[0];
				break;
			case 552:
				h1 = (RaceResult[1]->num < RaceResult[2]->num) ? RaceResult[1] : RaceResult[2];
				h2 = (RaceResult[1]->num < RaceResult[2]->num) ? RaceResult[2] : RaceResult[1];
				break;
			}
			DrawBox(625, y - 9, 670, y + 36, h1->backcolor, true);
			DrawStringToHandle(640 + ((h1->num < 10) ? 0 : -10), y, to_string(h1->num).c_str(), h1->fontcolor, font.horseinfo);
			DrawBox(725, y - 9, 770, y + 36, h2->backcolor, true);
			DrawStringToHandle(740 + ((h2->num < 10) ? 0 : -10), y, to_string(h2->num).c_str(), h2->fontcolor, font.horseinfo);
		}
			break;
		case 5://�O�A��
		{
			int d = (RaceResult[0]->num > RaceResult[1]->num) ? 100 : 0;
			d += (RaceResult[0]->num > RaceResult[2]->num) ? 10 : 0;
			d += (RaceResult[1]->num > RaceResult[2]->num) ? 1 : 0;
			auto h0 = RaceResult[0];
			auto h1 = RaceResult[1];
			auto h2 = RaceResult[2];
			switch (d) {
			case 0://  1 < 2, 1 < 3, 2 < 3  1 - 2 - 3
				break;
			case 1://  1 < 2, 1 < 3, 2 > 3  1 - 3 - 2
				h1 = RaceResult[2];
				h2 = RaceResult[1];
				break;
			case 10:// 1 < 2, 1 > 3, 2 < 3  �G���[
				return;
				break;
			case 11:// 1 < 2, 1 > 3, 2 > 3  3 - 1 - 2
				h0 = RaceResult[2];
				h1 = RaceResult[0];
				h2 = RaceResult[1];
				break;
			case 100://1 > 2, 1 < 3, 2 < 3  2 - 1 - 3
				h0 = RaceResult[1];
				h1 = RaceResult[0];
				break;
			case 101://1 > 2, 1 < 3, 2 > 3  �G���[
				return;
				break;
			case 110://1 > 2, 1 > 3, 2 < 3  2 - 3 - 1
				h0 = RaceResult[1];
				h1 = RaceResult[2];
				h2 = RaceResult[0];
				break;
			case 111://1 > 2, 1 > 3, 2 > 3  3 - 2 - 1
				h0 = RaceResult[2];				
				h2 = RaceResult[0];
				break;
			}
			DrawStringToHandle(640 , y, "-", GetColor(255, 255, 255), font.horseinfo);
			DrawStringToHandle(740 , y, "-", GetColor(255,255,255), font.horseinfo);
			DrawBox(575, y - 9, 620, y + 36, h0->backcolor, true);
			DrawStringToHandle(590 + ((h0->num < 10) ? 0 : -10), y, to_string(h0->num).c_str(), h0->fontcolor, font.horseinfo);
			DrawBox(675, y - 9, 720, y + 36, h1->backcolor, true);
			DrawStringToHandle(690 + ((h1->num < 10) ? 0 : -10), y, to_string(h1->num).c_str(), h1->fontcolor, font.horseinfo);
			DrawBox(775, y - 9, 820, y + 36, h2->backcolor, true);
			DrawStringToHandle(790 + ((h2->num < 10) ? 0 : -10), y, to_string(h2->num).c_str(), h2->fontcolor, font.horseinfo);
		}
			break;
		case 6://�O�A�P
		{
			auto h0 = RaceResult[0];
			auto h1 = RaceResult[1];
			auto h2 = RaceResult[2];
			DrawStringToHandle(640, y, ">", GetColor(255, 255, 255), font.horseinfo);
			DrawStringToHandle(740, y, ">", GetColor(255, 255, 255), font.horseinfo);
			DrawBox(575, y - 9, 620, y + 36, h0->backcolor, true);
			DrawStringToHandle(590 + ((h0->num < 10) ? 0 : -10), y, to_string(h0->num).c_str(), h0->fontcolor, font.horseinfo);
			DrawBox(675, y - 9, 720, y + 36, h1->backcolor, true);
			DrawStringToHandle(690 + ((h1->num < 10) ? 0 : -10), y, to_string(h1->num).c_str(), h1->fontcolor, font.horseinfo);
			DrawBox(775, y - 9, 820, y + 36, h2->backcolor, true);
			DrawStringToHandle(790 + ((h2->num < 10) ? 0 : -10), y, to_string(h2->num).c_str(), h2->fontcolor, font.horseinfo);
		}
			break;
		}
	}
	//�V���[�X���s��
	void NewGame() {		
		played.clear();
		played.shrink_to_fit();
		Player.totalbet = 0;
		Player.win = 0;
		select = 0;
		checking = false;
		CheckBaken();
		RaceResult.clear();
		hitbaken.clear();
		nowmenu = betmenu.end();
		nowrace.rate = RATE(GetRand(3));
		if (racename.size() == 0) {
			nowrace.name = "";
		}
		else {
			//�����_���Ƀ��[�X��������
		}
		nowrace.firld = (GetRand(1) == 1) ? true : false;
		nowrace.condition = CONDITION(GetRand(2));
		nowrace.weather = WEATHER(GetRand(2));
		nowrace.lane = (GetRand(26) + 10) * 100;
		nowrace.horsecount = GetRand(4) + 12;
		nowinfo = INFOMATION::rank;
		HORSE uma;
		int namer = 0;
		COLOR cnum[5][16] = {
			{white,black,red,blue,yellow,yellow,green,green,orange,orange,pink,pink,white,white,white,white},
			{white,black,red,blue,blue,yellow,yellow,green,green,orange,orange,pink,pink,white,white,white},
			{white,black,red,red,blue,blue,yellow,yellow,green,green,orange,orange,pink,pink,white,white},
			{white,black,black,red,red,blue,blue,yellow,yellow,green,green,orange,orange,pink,pink,white},
			{white,white,black,black,red,red,blue,blue,yellow,yellow,green,green,orange,orange,pink,pink,},
		};
		int rec = 0;
		this->horse.clear();
		this->horse.shrink_to_fit();
		for (int hc = 1; hc < nowrace.horsecount + 1; hc++) {
			uma.name = "";
			while (uma.name == "") {
				namer = GetRand(horsename.size() - 1);
				if (horsename[namer].use == false) {
					horsename[namer].use = true;
					uma.name = horsename[namer].name;
				}
			}
			uma.color = cnum[nowrace.horsecount - 12][hc - 1];
			GetHorseColor(uma.color, uma.fontcolor, uma.backcolor);
			uma.mind = MIND(GetRand(4));			
			uma.style = STYLE(GetRand(3));			
			for (int rc = 0; rc < 5; rc++) {
				uma.recordrate[rc] = WBC;
				uma.record[rc] = 0;
			}
			rec = 5;
			for (int rc = 0; rc < rec + 1; rc++) {
				int s = GetRand(39) + 1;
				if (s > 39) {
					uma.recordrate[rc] = RATE::WBC;
				}
				else {
					uma.recordrate[rc] = (RATE)((int)((s - 1) / 13) + 1);
				}
				uma.record[rc] = GetRand(15) + 1;
			}
			this->horse.push_back(uma);
		}
		for (auto hname = horsename.begin(); hname != horsename.end(); hname++) {			
			hname->use = false;
		}	
		int avg = (40 + (3 - nowrace.rate) * 10)/ 2;
		vector<int> value(40 + (3 - nowrace.rate) * 10 + 2);
		while (nowrace.totalvalue < (double)(avg * nowrace.horsecount - 20) || 
			nowrace.totalvalue > (double)(avg * nowrace.horsecount + 20)) {
			nowrace.totalvalue = 0;
			value.assign(40 + (3 - nowrace.rate) * 10 + 2, 0);
			for (auto h = horse.begin(); h != horse.end(); h++) {
				h->value = 0;
				while (h->value < 1 || value[(int)(h->value)] > 0) {
					h->value = (double)(GetRand(40 + (3 - nowrace.rate) * 10) + 1);
				}
				value[(int)(h->value)] += 1;
				nowrace.totalvalue += h->value;
				h->rank = 1;
			}
		}
		for (auto h = horse.begin(); h != horse.end(); h++) {
			for (auto hh = horse.begin(); hh != horse.end(); hh++) {
				if (h != hh && h->value < hh->value) {
					h->rank++;
				}
			}			
		}
		nowrace.totalvalue = 0;
		double deviation[6] = {//�l�C�΍��B��ʐl�C�n�̉��l�𒲐߂��A�I�b�Y��������B
			2.0,1.8,1.6,1.4,1.2,1.15
		};
		for (auto h = horse.begin(); h != horse.end(); h++) {
			if (h->rank < 1) {
				break;
			}
			if (h->rank < 7) {
				h->value *= deviation[h->rank - 1];
			}
			nowrace.totalvalue += h->value;
		}
		for (auto h = horse.begin(); h != horse.end(); h++) {
			h->win =  (double)(floor(nowrace.totalvalue / h->value * 10) / 10);
		}
		for (int h = 1; h < nowrace.horsecount + 1; h++) {
			horse[h - 1].win = (double)(floor((double)(nowrace.totalvalue) / horse[h - 1].value * 100) / 100);
		}
		for (auto m = betmenu.begin(); m != betmenu.end(); m++) {
			const int *img = (m->form >= FORM::wide) ? &sbimg : &bimg;
			m->ClearBakenData();
			m->CreateBakenBack(this->horse, *img, font.baken);
			m->NewGame(nowrace,horse,font.baken,font.odds);
		}
		
	}
	void game() {
		bool endflg = false;
		int clock = GetNowCount();
		for (auto m : FORM()) {
			vector<baken*> b;
			blist.push_back(b);
		}		
		if (SetDrawScreen(DX_SCREEN_BACK) != 0) {
			return;
		}
		NewGame();
		NewGame();//2�񃌁[�X��ݒ肷�邱�ƂŔn���\�����@�\�����Ă���B
		while (horse[0].rank < 0) {//�o�O���
			NewGame();
		}
		ChangeMusic();
		while (endflg == false) {
			flame = 0;
			clock = GetNowCount();				
			while (ClearDrawScreen() == 0 && ProcessMessage() == 0 && flame < 31 && endflg == false && GetNowCount() - clock < 1000) {				
				UpdateMouseCondition();
				GetMouseCondition();
				if (Mouse.click == 1 && Mousebefore.click != 1) {
					if (touch())SetSound();
					Mouse.click = 0;
				}				
				switch (nowmode) {
				case bet:
					DisplayMenu();
					if (Mouse.click == 3 || Mouse.click == 4) {
						touching();
					}
					break;
				case race://�����_�ł͖�����
					break;
				case result:
					DisplayResult();
					break;
				case config:
					ProcessOption();
					break;
				case io:
					//�f�[�^���Z�[�u���ăQ�[���I��
					Save();
					endflg = true;
					break;
				}
				
				//DrawString(550, 100, to_string(Mouse.corsor).c_str(), GetColor(0, 0, 0));
				//if (nowmenu != betmenu.end()) {
					//DrawString(600, 100, to_string(nowmenu->GetSelect2()).c_str(), GetColor(0, 0, 0));
				//}
				//DrawString(550, 110, to_string(Mouse.x).c_str(), GetColor(0, 0, 0));
				//DrawString(550, 120, to_string(Mouse.y).c_str(), GetColor(0, 0, 0));
				//fps(flame);*/
				
				if (ScreenFlip() != 0) { endflg = true; }
				if (GetNowCount() - clock > 1000) {
					break;
				}
				flame++;				
			}	
			
		}
	}
	//SE��炷
	void SetSound() {
		SOUND s = (SOUND)(-1);
		switch (Mouse.corsor) {
		case BNAME::menubar:
		//case BNAME::horse:
		case BNAME::info:
			s = SEinfo;
			break;
		case BNAME::betrate:
		case BNAME::start:
		case BNAME::FBFplot:
		//case BNAME::End:
			s = SEselect;
			break;
		case BNAME::betlist:
			s = SEbetmenu;
			break;
		case BNAME::bet1:
		case BNAME::bet2:
		case BNAME::FBFbaken:
			s = SEbet;
			break;
		case BNAME::FBFallbet:
			s = SEallbet;
			break;		
		case BNAME::FBFoddsnum:
		case BNAME::down:
		case BNAME::up:
		case BNAME::bflow:
		case BNAME::bbox:
		case BNAME::bforma:
			s = SEFBF;
			break;
		case BNAME::Undo:
		case BNAME::FBFcancel:
			s = SEcancel;
			break;		
		}
		if (s != (SOUND)(-1)) {
			PlaySoundMem(Sound[s], DX_PLAYTYPE_BACK, true);
		}
	}
	//���y��؂�ւ���
	void ChangeMusic() {
		int m = -1;
		switch (nowmode) {
		case MODE::bet:
			
			switch (nowrace.rate) {
			case RATE::G2:
				m = 3;
				break;
			case RATE::G3:
				m = 4;
				break;
			default:
				m = 2;
				break;
			}
			break;
		case MODE::result:
			m = 1;
			break;

		}
		
		if (m > -1) {
			string bgm = "./data/BGM�ESE/BGM" + to_string(m) + ".mp3";
			if (Music != 0) DeleteSoundMem(Music);
			Music = LoadSoundMem(bgm.c_str());
			PlaySoundMem(Music, DX_PLAYTYPE_LOOP);
			ChangeVolumeSoundMem((Player.BGMVolume == 10) ? 255 : Player.BGMVolume * 26, Music);
		}
	}
	void fps(int count) {
		int i;
		static int t = 0, ave = 0, f[30];
		f[count % 30] = GetNowCount() - t;
		t = GetNowCount();
		if (count % 30 == 29) {
			ave = 0;
			for (i = 0; i < 30; i++)
				ave += f[i];
			ave /= 30;
		}
		if (ave != 0) {
			DrawFormatString(1270, 600, GetColor(255, 255, 255), "%.1fFPS", 1000.0 / (double)ave);
			DrawFormatString(1350, 600, GetColor(255, 255, 255), "%dms", ave);
		}
		return;
	}
	void GetHorseColor(COLOR color,int &fontcolor,int &backcolor) {
		switch (color) {
		case white:
			backcolor = GetColor(250, 250, 250);
			fontcolor = GetColor(0, 0, 0);
			break;
		case black:
			fontcolor = GetColor(250, 250, 250);
			backcolor = GetColor(0, 0, 0);
			break;
		case red:
			fontcolor = GetColor(250, 250, 250);
			backcolor = GetColor(255, 50, 0);
			break;
		case blue:
			fontcolor = GetColor(250, 250, 250);
			backcolor = GetColor(50, 0, 255);
			break;
		case yellow:
			fontcolor = GetColor(0, 0, 0);
			backcolor = GetColor(230, 230, 0);
			break;
		case green:
			fontcolor = GetColor(240, 240, 240);
			backcolor = GetColor(0, 180, 25);
			break;
		case orange:
			fontcolor = GetColor(240, 240, 240);
			backcolor = GetColor(255, 150, 0);
			break;
		case pink:
			fontcolor = GetColor(240, 240, 240);
			backcolor = GetColor(255, 0, 150);
			break;
		}
	}
private:
	void UpdateMouseCondition() {
		Mousebefore.x = Mouse.x;
		Mousebefore.y = Mouse.y;
		Mousebefore.clickbutton = Mouse.clickbutton;
		Mousebefore.clickcount = Mouse.clickcount;
		Mousebefore.clicklog = Mouse.clicklog;
		Mousebefore.corsor = Mouse.corsor;
	}
	void GetMouseCondition() {
		int m = GetMouseInputLog2(&Mouse.clickbutton, &Mouse.x, &Mouse.y, &Mouse.clicklog, TRUE);

		if (m < 1) {
			//�}�E�X����
			Mouse.wheel += GetMouseWheelRotVol() * -10;
			if (Mouse.clickbutton == MOUSE_INPUT_LEFT) {
				if (Mousebefore.clicklog == MOUSE_INPUT_LOG_UP && Mouse.clicklog == MOUSE_INPUT_LOG_DOWN) {//1�t���[�����Ƀ}�E�X���N���b�N���ꂽ�ꍇ
					Mouse.clickcount++;//1�t���[�����̃N���b�N�����J�E���g
					Mouse.click = 4;//�}�E�X���N���b�N�����܂�				
				}
			}
			if (Mousebefore.clicklog == MOUSE_INPUT_LOG_DOWN && Mouse.clicklog == MOUSE_INPUT_LOG_UP) {//1�t���[�����Ƀ}�E�X�{�^���������ꂽ�ꍇ
				Mousebefore.click = Mouse.click;
				switch (Mouse.clickcount) {
				case 1:
					Mouse.click = 1;//�V���O���N���b�N		
					Mouse.clickf = GetNowCount();
					break;
				case 2:
					Mouse.click = 2;//�_�u���N���b�N
					Mouse.clickcount = 0;
					break;
				}
			}
			if (Mousebefore.clicklog == MOUSE_INPUT_LOG_UP && Mouse.clicklog == MOUSE_INPUT_LOG_UP) {//1�t���[�����Ƀ}�E�X�{�^���������ꂽ�ꍇ
				if (Mouse.clickf > 0 && GetNowCount() - Mouse.clickf >= 60) {
					Mouse.click = 0;
					Mouse.clickcount = 0;
					Mouse.clickf = 0;
				}
			}
			GetMousePoint(&Mouse.x, &Mouse.y);
			if (Mousebefore.clicklog == MOUSE_INPUT_LOG_DOWN && Mouse.clicklog == MOUSE_INPUT_LOG_DOWN && (Mousebefore.x != Mouse.x || Mousebefore.y != Mouse.y)) {//1�t���[�����Ƀ}�E�X�{�^���������ꑱ�����ꍇ
				Mouse.click = 3;//�h���b�O���
			}
			if (Mouse.clickf > 0 && GetNowCount() - Mouse.clickf >= 500) {
				Mouse.clickcount = 0;
				Mouse.clickf = 0;
			}
		}
		else {
			//�^�b�`�p�l������
			if (GetTouchInputNum() > 0) {
				//�^�b�`�p�l�����^�b�v���Ă���
				m = GetTouchInput(0, &Mouse.x, &Mouse.y, NULL, NULL);
				switch (Mousebefore.click) {
				case 0:
					Mouse.click = 4;
					break;
				case 2:
					Mouse.click = 0;
					Mouse.clickcount = 0;
					break;
				case 3://Mouse.y�̕ω��ɉ����ăX�N���[������������
					Mouse.wheel += Mouse.y - Mousebefore.y;
					break;
				case 4:
					if (Mousebefore.x != Mouse.x || Mousebefore.y != Mouse.y) {
						Mouse.click = 3;
					}
					break;
				}
			}
			else {
				//�^�b�`�p�l���ɐG��Ă��Ȃ�
				switch (Mousebefore.click) {
				case 0:
					if (Mouse.clickf > 0 && GetNowCount() - Mouse.clickf >= 60) {
						Mouse.click = 0;
						Mouse.clickcount = 0;
						Mouse.clickf = 0;
					}
					break;
				case 1:
				case 3:
				case 4:
					Mousebefore.click = Mouse.click;
					Mouse.clickcount++;
					if (Mouse.clickcount == 1) {
						//�V���O���^�b�v
						Mouse.click = 1;
						Mouse.clickf = GetNowCount();
					}
					else {
						//�_�u���^�b�v
						Mouse.click = 2;
						Mouse.clickcount = 0;
					}
					break;
				case 2:
					Mouse.click = 0;
					Mouse.clickf = 0;
					break;

				}

			}
			if (Mouse.clickf > 0 && GetNowCount() - Mouse.clickf >= 500) {
				Mouse.clickcount = 0;
				Mouse.clickf = 0;
			}
		}
		//��ʂ̑傫�����قȂ�ʃn�[�h�p		
		Mouse.x *= 1450;
		Mouse.y *= 910;
		Mouse.x /= Width;
		Mouse.y /= Height;
		//DrawFormatString(100, 80, GetColor(0, 0, 0), "Mouse.clickbutton = %d", Mouse.clickbutton);

		//DrawFormatString(100, 120, GetColor(0, 0, 0), "Mouse.x = %d", Mouse.x);
		//DrawFormatString(100, 140, GetColor(0, 0, 0), "Mouse.y = %d", Mouse.y);
		//DrawFormatString(100, 160, GetColor(0, 0, 0), "Mouse.clickcount = %d", Mouse.clickcount);
		//DrawFormatString(100, 180, GetColor(0, 0, 0), "Mouse.clicklog = %d", Mouse.clicklog);
		//DrawFormatString(100, 200, GetColor(0, 0, 0), "Mouse.clickf = %d", Mouse.clickf);
	}
	const int bimg = LoadGraph("data/baken.png");//1�`2�A�n���摜�B
	const int sbimg = LoadGraph("data/sanbaken.png");//3�A�n���摜�B
	const int bakenback = LoadGraph("data/bakenback.png");//�n�����j���[�w�i�摜�B1�`2�A�n�p�B
	const int sbakenback = LoadGraph("data/sbakenback.png");//�n�����j���[�w�i�摜�B3�A�n�p�B
	const int MainImage = LoadGraph("data/mainflame.png");//���C����ʉ摜�B	
	const int FBFImage = LoadGraph("data/FBF.png");//FBF�I���{�^���摜�B
	const int StartImage = LoadGraph("data/start.png");//���[�X�J�n�{�^���摜�B
	const int End = LoadGraph("data/END.png");//�I���{�^���摜�B
	const int ConfigImage = LoadGraph("data/option.png");//�I�v�V�����{�^���摜�B
	const int ResetImage = LoadGraph("data/resetimg.png");//�S�f�[�^�������m�F�摜�B
	const int bshadow = LoadGraph("data/bshadow.png");//�e���{�^���摜�B
	const int ListUp = LoadGraph("data/listup.png");//BET�ꗗ����{�^���B�㉺�t�ɕ`�ʂ��邱�Ƃ�����B
	const int CheckSheet = LoadGraph("data/betlist.png");//BET�ꗗ�摜
	const int Back = LoadGraph("data/back.png");//�߂�{�^���BBET�ꗗ�{�^���Ɠ����ʒu�ɕ`�ʂ����B
	const int Condition = LoadGraph("data/condition.png");//�n��ԉ摜�B�n�R���f�B�V�����ɉ����ĉ�]�`�ʂ���B
	const int Style = LoadGraph("data/style.png");//���E�i�E���E�ǂ̃X�^�C����\�����邽�߂̉摜�B�e�n�ɊY������X�^�C���ɂ͐F�t�����Ȃ����B
	const int RecordImg = LoadGraph("data/record.png");//�O5���[�X�̃����N�ƌ��ʂ�\�����邽�߂̉摜�B�e�n�̃��R�[�h���Q�Ƃ���B
	const int SubImage = LoadGraph("data/subflame.png");//�T�u��ʉ摜�B
	const int SubButton = LoadGraph("data/FBFfield.png");//�T�u��ʑI���{�^���摜�B
	const int SubSelect = LoadGraph("data/FBFselect.png");//�T�u��ʑI�𒆉摜�B
	const int SubOdds = LoadGraph("data/FBFodds.png");//�T�u��ʂł̃I�b�Y���\��������킷�摜
	const int SubNum = LoadGraph("data/FBFnum.png");//�T�u��ʂł̔n�ԏ��\��������킷�摜
	const int ResultImg = LoadGraph("data/Result.png");//���ʕ\�����
	int configback;//�I�v�V������ʂ̕\�����ɔw�i�Ƃ��ĕ`�ʂ����摜�B�I�v�V�����{�^���N���b�N���ɕۑ������B
	INFOMATION nowinfo;//���ݕ\������Ă���n���B�z�[�����j���[�ł͂R�̏��ABET���j���[�ł͂P�̏�񂪕\�������B
	int select;//���ݑI�𒆂̔n�B���j���[�؂�ւ����ɔ��f����Aselect�ɉ������n�����\�������B
	bool oddsnum;//�T�u���j���[�W�J���ɕ\�������n�����I�b�Y���ɕ\��(=true)���邩�n�ԍ����ɕ\��(=false)���邩�������B
	bool checking;//����܂ł�BET�����n���̈ꗗ��true�ł���Ε\���B�܂��eBET��ʂł͂��̌`���̔n���̂ݕ\���B
	bool resetcheck;//config���ɏ�������I�����ꂽ����true�ƂȂ�B���̎��m�F��ʂ�\�����A����ɏ����������F���ꂽ�ꍇ�̓v���C���[�f�[�^������������B
	RACE nowrace;
	vector<menu> betmenu;//���j���[�ꗗ�B�P���E��������O�A�P�܂ł̉�ʏ������^�B�܂��z�[�����j���[�ƌ��ʉ�ʂ͑��݂��Ȃ��B
	vector<botan> button;//�{�^���ꗗ�B
	vector<menu>::iterator nowmenu;//���ݕ\������Ă��郁�j���[�B�z�[�����j���[�̎���=betmenu.end()�ƂȂ�B
	vector<HORSE> horse;//12�`16���܂�
	vector<string>racename;//���[�X���ꗗ ���[�X���ƂɃf�[�^���쐬���邩�͖���
	struct HORSENAME {
		string name;
		bool use;
	};
	vector<HORSENAME>horsename;//�n���ꗗ �n���ɃX�e�[�^�X��ݒ肷�邩�͖���	
	struct PLAYED {
		PLAYED(FORM f, baken* b, int cp,int st) :form(f), bak(b), chip(cp),step(st){

		}
		FORM form;//bet�����n���̎��
		baken* bak;//bet�����n����oddsdata�ւ̃C�e���[�^
		int chip;//�|����
		int step;//�v���C�������ԁB
		bool operator==(FORM &f) {
			return form == f;
		}
	};
	vector<PLAYED> played;//�v���C���[�̑���L�^�B	
	bool winwide;//BET�ꗗ�̂����P���`���C�h�ꗗ���\������Ă���ꍇtrue�ƂȂ�Bfalse�̏ꍇ�O�A���E�O�A�P���\�������B
	vector<vector<baken*>> blist;//�n�����(form)���Ƃɂ܂Ƃ߂�ꂽBET�ς݂̔n�����Boddsdata�ւ̃|�C���^���i�[����Ă���B
	vector<int> listlimit;//blist�̊J�n�ʒu���i�[�����vector�B
	struct mOUSE {
		int x;//�J�[�\����X���W�B
		int y;//�J�[�\����X���W�B
		int clickcount;//1�t���[�����ɍ��{�^�����N���b�N�����񐔂�ێ�����ϐ��B
		int clickf;//�ŏ��ɃN���b�N���ꂽ���̃t���[�����B���ꂪ500F�𒴂���O�ɍēx�N���b�N���ꂽ��_�u���N���b�N�ƂȂ�B
		int clicklog;//�{�^���������ꂽ�̂������ꂽ�̂��������ϐ��B
		int clickbutton;//�N���b�N���ꂽ�{�^���̎�ށB��{�͍��N���b�N�݂̂ő���\
		int click;//�N���b�N�̎�ށB0.������Ă��Ȃ� 1.�V���O���N���b�N 2.�_�u���N���b�N 3.�h���b�O 4.�N���b�N�����܂ܓ����Ȃ�
		int wheel;//�z�C�[���̉�]�ʁB�v���X�̏ꍇ�͉�ʂ����ɃX�N���[�����A�}�C�i�X�̏ꍇ�͏�ɃX�N���[������B
		BNAME corsor;//���݂̃J�[�\�����w�������{�^���܂��͉�ʁB�N���b�N���ꂽ���̍��W����touch���\�b�h�Ō��肷��B
	};
	struct PLAYER {
		string name;//�v���C���[��
		int ID;//�v���C���[ID
		vector<int>::iterator chip;//�n��BET��񓖂���̓q����
		int cash;//�����B��������ʂ�CREDIT�ɂ�totalbet�������ꂽ�c�z���\�������B
		int BGMVolume;//BGM����0(0),26(1)�c239(9),255(10)�Ƃ��A0�`10�Ŏ��ʂ���0�`255�ɕϊ�����B
		int SEVolume;//BGM����0(0),26(1)�c239(9),255(10)�Ƃ��A0�`10�Ŏ��ʂ���0�`255�ɕϊ�����B
		int maxconbo;//�ő�A�����B�|�����ɑ΂��z������2�{�̎��ɃR���{�����Z�����B
		int maxwin;//�z���̍ō��z�B
		int totalbet;//�|�������v
		int win;//�O��̔z��
		int conbo;//���Q�[�����̘A�����B�|�����ɑ΂��z������2�{�̎��ɃR���{�����Z�����B
	};
	struct Font {
		int horseinfo;//�n�ԍ��E�n����\������Ƃ��̃t�H���g
		int baken;//�n���{�^���̃��x���̕\���Ɏg����t�H���g
		int odds;//�n���{�^���̃I�b�Y�̕\���Ɏg����t�H���g
		int top3odds;//�����n���̃I�b�Y�\���݂̂Ɏg����t�H���g
		int record;//�n���̃��R�[�h���ʂ�\�����邽�߂̃t�H���g
		int result;//���U���g��ʂł̊m��I�b�Y�̕\���Ɏg����t�H���g
	};
	vector<int>Sound;//���ʉ��n���h�����i�[����vector�BSOUND�񋓌^�ŃA�N�Z�X����B
	Font font;
	PLAYER Player;
	int Music = 0;//BGM�n���h���B���y���؂�ς�邲�Ƃɓǂݍ��܂��B
	
	MODE nowmode;//���݂̃Q�[�����[�h�B0.BETMODE 1.RACE 2.RESULT 3.I/O
	vector<int>BetRate = { 1,2,5,10,100,500,1000 };//BET���[�g�B�{�^����������邱�Ƃň�x�̃N���b�N�łǂ�قǓq�����邩���ς��B
	vector<int>::iterator operator=(const vector<int>::iterator rate){
		return rate;
	}
	vector<vector<HORSE>::iterator>RaceResult;//���[�X���ʁBHorse����o�^�B	
	struct hit {
		hit(FORM nf, double od, int be) :f(nf), odds(od), bet(be) {

		}
		FORM f;
		double odds;//��{��baken�ɂ���odds�Ɠ��ꂾ���A�����E���C�h�̓��[�X���ʂ����ɉ��߂ăI�b�Y�v�Z�������Ȃ��B
		int bet;
	};
	vector<hit> hitbaken;//�P���A�����~3�A�n�A�A�n�P�A���C�h�~3,�O�A���A�O�A�P��baken�N���X�Ɗm��I�b�Y��o�^�B
	vector<botan> betlistbutton;//BET�ꗗ�\�����ɑ���ł���{�^���Q�B0�`6.up,7�`13.down,14.totriple,15.towinwide
	mOUSE Mouse;
	mOUSE Mousebefore;
};
