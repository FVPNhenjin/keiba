#include <DxLib.h>
#include <stdlib.h>
#include<stdio.h>
#include <crtdbg.h>
#include <windows.h>
#include<iostream>
#include <fstream>
#include <winbase.h>
#include <crtdbg.h>
#include <direct.h>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <iterator>
#include <algorithm>
using namespace std;
#include<math.h>
#define PI 3.1415926535
#define ToName(x) (#x)//�ϐ��ɕt����ꂽ�ϐ����𕶎���(const Char *)�ɕϊ����܂��B

